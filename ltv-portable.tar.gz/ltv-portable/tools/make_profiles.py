#!/usr/bin/env python3
"""Собирает source-connections.v1 для OpenShift/JVM и добавляет блок tls (mTLS, ADR 0025).

Использует генератор продукта tools/platform_profiles.py без изменений, затем дописывает в каждый профиль
`tls` (ca_file, client_keystore_file, client_keystore_password_env). Пароль и ключи сюда не попадают:
только пути и ИМЯ переменной окружения. Только стандартная библиотека Python 3.9+.

  python3 tools/make_profiles.py --config config/profile-config.json --out config/source-connections.json \
      --ca "$LTV_TLS_CA_FILE" --p12 "$LTV_TLS_CLIENT_P12" --password-env LTV_GRAFANA_MTLS_PASSWORD
"""
import argparse
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from tools.platform_profiles import build_connections, serialize  # noqa: E402


def main(argv):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--ca", default=os.environ.get("LTV_TLS_CA_FILE", ""))
    parser.add_argument("--p12", default=os.environ.get("LTV_TLS_CLIENT_P12", ""))
    parser.add_argument("--password-env", default="LTV_GRAFANA_MTLS_PASSWORD")
    parser.add_argument("--no-tls", action="store_true", help="не добавлять tls (http-стенд или публичный CA без клиентского сертификата)")
    args = parser.parse_args(argv)
    with open(args.config, encoding="utf-8") as handle:
        config = json.load(handle)
    document = build_connections(config)
    if not args.no_tls:
        tls = {}
        if args.ca:
            tls["ca_file"] = args.ca
        if args.p12:
            tls["client_keystore_file"] = args.p12
            tls["client_keystore_password_env"] = args.password_env
        for key in ("ca_file", "client_keystore_file"):
            path = tls.get(key)
            if path and not (path.startswith("/") or (len(path) > 2 and path[1] == ":")):
                raise SystemExit(f"{key} должен быть абсолютным путём: {path}")
        if not tls:
            raise SystemExit("нет ни --ca, ни --p12 (или используйте --no-tls)")
        for connection in document["connections"]:
            if not connection["base_url"].startswith("https://"):
                raise SystemExit("tls допустим только при base_url https://")
            connection["tls"] = dict(tls)
    with open(args.out, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(serialize(document))
    print(f"OK: {len(document['connections'])} профилей, {sum(len(c['queries']) for c in document['connections'])} запросов -> {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
