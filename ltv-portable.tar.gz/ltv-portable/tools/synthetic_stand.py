#!/usr/bin/env python3
"""Лёгкая замена Docker-стенда демо: отвечает на Grafana-proxy query_range рядами из metrics.om.

Это НЕ Grafana и НЕ Prometheus: понимает только запросы профиля demo-grafana
(round(avg_over_time(<метрика>{<метки>}[<шаг>]), 0.000001)) и отдаёт значения из synthetic/metrics.om.
Слушает 127.0.0.1:13000 (как стенд), чтобы работал тот же config/source-connections.synthetic-demo-stand.json.
Не поддерживает: Render PNG панелей Grafana, дашборд, другие PromQL. Только стандартная библиотека.

  python3 tools/synthetic_stand.py [--om synthetic/metrics.om] [--port 13000] [--window closed|open]
"""
import argparse
import json
import re
import sys
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_EVEN
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

SAMPLE = re.compile(r'^([A-Za-z_:][A-Za-z0-9_:]*)(?:\{(.*)\})?\s+(\S+)\s+(\d+(?:\.\d+)?)\s*$')
LABEL = re.compile(r'([A-Za-z_][A-Za-z0-9_]*)\s*(=~|!=|!~|=)\s*"((?:[^"\\]|\\.)*)"')
QUERY = re.compile(r'^round\(\s*avg_over_time\(\s*([A-Za-z_:][A-Za-z0-9_:]*)\s*(?:\{(.*)\})?\s*\[(\d+)(ms|s|m)\]\s*\)\s*,\s*([0-9.]+)\s*\)$')
PATH = re.compile(r'^/api/datasources/proxy/uid/([A-Za-z0-9._~-]+)/api/v1/query_range$')
SERIES = defaultdict(list)  # (metric, frozenset(labels)) -> [(ts_ms, value)]


def load(path):
    n = 0
    with open(path, encoding='utf-8') as handle:
        for line in handle:
            if line.startswith('#') or not line.strip():
                continue
            m = SAMPLE.match(line)
            if not m:
                continue
            labels = frozenset((k, v) for k, _, v in LABEL.findall(m.group(2) or ''))
            SERIES[(m.group(1), labels)].append((int(round(float(m.group(4)) * 1000)), float(m.group(3))))
            n += 1
    for values in SERIES.values():
        values.sort()
    return n


def matchers(text):
    return [(k, op, v) for k, op, v in LABEL.findall(text or '')]


def selected(metric, ms):
    out = []
    for (name, labels), values in SERIES.items():
        if name != metric:
            continue
        d = dict(labels)
        ok = True
        for k, op, v in ms:
            have = d.get(k, '')
            if op == '=' and have != v or op == '!=' and have == v:
                ok = False
            elif op in ('=~', '!~'):
                hit = re.fullmatch(v, have) is not None
                if (op == '=~') != hit:
                    ok = False
        if ok:
            out.append((d, values))
    return out


def range_query(expression, start_s, end_s, step_s, closed):
    m = QUERY.match(expression.strip())
    if not m:
        raise ValueError('unsupported expression')
    metric, label_text, num, unit, rnd = m.groups()
    window_ms = int(num) * {'ms': 1, 's': 1000, 'm': 60000}[unit]
    quant = Decimal(rnd)
    result = []
    for labels, values in selected(metric, matchers(label_text)):
        points = []
        t = int(start_s * 1000)
        while t <= int(end_s * 1000):
            lo = t - window_ms
            chosen = [v for ts, v in values if (lo <= ts <= t if closed else lo < ts <= t)]
            if chosen:
                avg = Decimal(repr(sum(chosen) / len(chosen)))
                points.append([t // 1000 if t % 1000 == 0 else t / 1000, str((avg / quant).quantize(Decimal(1), rounding=ROUND_HALF_EVEN) * quant).rstrip('0').rstrip('.') or '0'])
            t += int(step_s * 1000)
        if points:
            result.append({'metric': {'__name__': metric, **labels}, 'values': points})
    return result


class Handler(BaseHTTPRequestHandler):
    closed = False

    def _send(self, code, body, ctype='application/json'):
        raw = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        url = urlparse(self.path)
        if url.path == '/api/health':
            return self._send(200, {'database': 'ok', 'version': 'synthetic-stand'})
        if PATH.match(url.path):
            q = parse_qs(url.query)
            try:
                result = range_query(q['query'][0], float(q['start'][0]), float(q['end'][0]), float(q['step'][0]), self.closed)
            except (KeyError, ValueError) as error:
                return self._send(400, {'status': 'error', 'errorType': 'bad_data', 'error': str(error)})
            return self._send(200, {'status': 'success', 'data': {'resultType': 'matrix', 'result': result}})
        self._send(404, {'message': 'not available in the synthetic stand (no Grafana dashboards or image renderer)'})

    def log_message(self, *args):
        pass


def main(argv):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--om', default='synthetic/metrics.om')
    p.add_argument('--port', type=int, default=13000)
    p.add_argument('--window', choices=('open', 'closed'), default='open', help='левая граница окна avg_over_time (Prometheus 3: open)')
    a = p.parse_args(argv)
    Handler.closed = a.window == 'closed'
    print(f'загружено {load(a.om)} точек, {len(SERIES)} рядов', flush=True)
    server = ThreadingHTTPServer(('127.0.0.1', a.port), Handler)
    print(f'синтетический стенд: http://127.0.0.1:{a.port} (Ctrl+C - остановка)', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
