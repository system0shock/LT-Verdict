#!/usr/bin/env bash
# LT Verdict portable: проверка готовности машины к демо. БЕЗ платных запросов, без отправки данных и ключей.
#
#   ./preflight.sh                 быстрая проверка (Java, Node, дистрибутив, конфиги, переменные, TCP/TLS)
#   ./preflight.sh --deep          + проверка PKCS12 (пароль, срок) и mTLS-запрос GET /api/health через curl
#   ./preflight.sh --no-ai         не проверять ИИ (форк Qwen, LLM, модели)
#   ./preflight.sh --no-net        не ходить в сеть (только локальные проверки)
#   ./preflight.sh --synthetic     только Java/дистрибутив/каталог (запасной вариант без стенда)
#
# Значения секретов не печатаются: только факт наличия переменной. Код возврата = число FAIL.
set -u
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export LTV_PORTABLE_HOME="${LTV_PORTABLE_HOME:-$HERE}"
DEEP=0; NOAI=0; NONET=0; SYN=0; PWENV=""; CONN="${LTV_CONNECTIONS_FILE:-$HERE/config/source-connections.json}"
for a in "$@"; do case "$a" in --deep) DEEP=1;; --no-ai) NOAI=1;; --no-net) NONET=1;; --synthetic) SYN=1; NOAI=1; NONET=1;; -h|--help) sed -n 2,10p "$0"; exit 0;; *) echo "неизвестный ключ: $a"; exit 2;; esac; done
# shellcheck disable=SC1091
[ -f "$HERE/config/env.sh" ] && . "$HERE/config/env.sh"
case "${LT_VERDICT_AI_RUNNER_MODE-__unset__}" in local) AIMODE=local;; __unset__) AIMODE=docker;; *) AIMODE=bad;; esac

FAILS=0; WARNS=0
ok()   { printf '[ OK ] %s\n' "$1"; }
info() { printf '[INFO] %s\n' "$1"; }
skip() { printf '[SKIP] %s\n' "$1"; }
warn() { printf '[WARN] %s\n       -> %s\n' "$1" "${2:-}"; WARNS=$((WARNS+1)); }
fail() { printf '[FAIL] %s\n       -> %s\n' "$1" "${2:-}"; FAILS=$((FAILS+1)); }
section() { printf '\n== %s ==\n' "$1"; }
have() { command -v "$1" >/dev/null 2>&1; }
setp() { [ -n "${1:-}" ] && eval "[ -n \"\${$1:-}\" ]"; }   # переменная задана и непуста (значение наружу не читается)

TMPD="$(mktemp -d "${TMPDIR:-/tmp}/ltv-preflight.XXXXXX")"; chmod 700 "$TMPD"
trap 'rm -rf "$TMPD"' EXIT
TO=""; have timeout && TO="timeout"

# JSON-помощник: node -e с кодом в $1, аргументы далее. Печатает результат кода на stdout.
HAVE_NODE=0; have node && HAVE_NODE=1
nodejs() { local code="$1"; shift; node -e "$code" "$@"; }

# ---------------------------------------------------------------- Java
section "Java и дистрибутив"
JAVA_BIN="java"; [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/java" ] && JAVA_BIN="$JAVA_HOME/bin/java"
if have "$JAVA_BIN" || [ -x "$JAVA_BIN" ]; then
  jv="$("$JAVA_BIN" -version 2>&1 | head -1)"
  jm="$(printf '%s' "$jv" | sed -E 's/.*version "([0-9]+)(\.[0-9]+)?.*/\1/')"
  case "$jm" in ''|*[!0-9]*) warn "Java: не удалось разобрать версию: $jv" "нужен JDK/JRE 21 или новее";;
    *) if [ "$jm" -ge 21 ]; then ok "Java $jm ($jv) - сборка таргетит 21, подходит 21+"; else fail "Java $jm слишком старая ($jv)" "установите Java 21+ или задайте JAVA_HOME; бандл собран на JDK 21 (class file 65), на Java 17 не запустится"; fi;; esac
else
  fail "Java не найдена" "установите Java 21+ или задайте JAVA_HOME"
fi
if [ -x "$HERE/ltv/bin/ltv" ]; then ok "ltv/bin/ltv есть и исполняемый"; elif [ -f "$HERE/ltv/bin/ltv" ]; then fail "ltv/bin/ltv не исполняемый" "chmod +x ltv/bin/ltv start.sh preflight.sh"; else fail "нет ltv/bin/ltv" "распакуйте бандл целиком"; fi
if [ -f "$HERE/ltv/lib/lt-verdict.jar" ]; then
  UIJAR=unknown
  if have unzip; then
    if unzip -l "$HERE/ltv/lib/lt-verdict.jar" 2>/dev/null | grep -q ' web/index.html'; then UIJAR=yes; else UIJAR=no; fi
  elif have python3; then
    if python3 -c 'import sys,zipfile;sys.exit(0 if "web/index.html" in zipfile.ZipFile(sys.argv[1]).namelist() else 1)' "$HERE/ltv/lib/lt-verdict.jar" 2>/dev/null; then UIJAR=yes; else UIJAR=no; fi
  fi
  if [ "$UIJAR" = yes ]; then ok "в lt-verdict.jar есть web/index.html (интерфейс встроен, отдельная сборка ui/ не нужна)"
  elif [ "$UIJAR" = no ]; then fail "в lt-verdict.jar нет web/index.html" "бандл собран без UI"
  else skip "нет ни unzip, ни python3: наличие встроенного UI не проверено"; fi
else fail "нет ltv/lib/lt-verdict.jar" "распакуйте бандл целиком"; fi

# ---------------------------------------------------------------- Node / Python
section "Node и вспомогательные инструменты"
if [ "$HAVE_NODE" = 1 ]; then
  nv="$(node -v 2>/dev/null)"; nm="${nv#v}"; nm="${nm%%.*}"
  if [ "${nm:-0}" -ge 22 ] 2>/dev/null; then ok "Node $nv (форк Qwen 0.21.x требует Node 22+)"; else warn "Node $nv старее 22" "Qwen Code 0.21.x заявляет Node >=22; форк - сверьте с его требованиями"; fi
else
  warn "Node не найден" "нужен для запуска форка Qwen (если он на Node) и для части проверок этого скрипта"
fi
if pv="$(python3 -c 'import sys;print("%d.%d"%sys.version_info[:2]);sys.exit(0 if sys.version_info>=(3,9) else 1)' 2>/dev/null)"; then ok "python3 $pv - можно собирать профили: tools/make_profiles.py"; else warn "python3 нет" "профили OpenShift/JVM не сгенерировать на этой машине; сгенерируйте на другой и скопируйте config/source-connections.json"; fi
have openssl && ok "openssl есть" || warn "openssl нет" "TLS-проверки будут пропущены"
have curl && ok "curl есть" || warn "curl нет" "mTLS-запрос GET /api/health (--deep) будет пропущен"

# ---------------------------------------------------------------- каталог данных и порт
section "Каталог данных и порт"
DATA="${LTV_DATA_DIR:-$HERE/data}"
if mkdir -p "$DATA" 2>/dev/null && [ -w "$DATA" ]; then ok "каталог данных доступен для записи: $DATA"; else fail "каталог данных недоступен: $DATA" "задайте LTV_DATA_DIR или права на каталог"; fi
info "порт веб-сервера выбирается случайно и слушает только 127.0.0.1 (--port у продукта нет); адрес печатается в консоль и в logs/ltv.log"
if [ "$HAVE_NODE" = 1 ]; then
  if nodejs 'const s=require("net").createServer();s.on("error",()=>process.exit(1));s.listen(0,"127.0.0.1",()=>{s.close();process.exit(0)})'; then ok "loopback 127.0.0.1: слушающий сокет открывается"; else fail "не удалось открыть сокет на 127.0.0.1" "политика безопасности/сеть хоста"; fi
else skip "порт: нужен node для проверки"; fi

# ---------------------------------------------------------------- переменные
if [ "$SYN" = 1 ]; then section "Переменные и профили источника"; skip "--synthetic: боевые источники не используются"; else
section "Переменные окружения (только наличие)"
check_var() { # имя, обязательность(req|opt), пояснение
  if setp "$1"; then ok "$1 задана"; elif [ "$2" = req ]; then fail "$1 не задана" "$3"; else info "$1 не задана ($3)"; fi
}
check_var GRAFANA_URL req "адрес Grafana/ingress боевого стенда, https://host (см. config/env.example.sh)"
check_var PROMETHEUS_URL opt "нужна только для transport direct"
check_var LTV_CONNECTIONS_FILE req "путь к config/source-connections.json"
# имя переменной с паролем PKCS12 берём из самого файла профилей
PWENV=""
CONN="${LTV_CONNECTIONS_FILE:-$HERE/config/source-connections.json}"
if [ "$HAVE_NODE" = 1 ] && [ -f "$CONN" ]; then
  PWENV="$(nodejs 'try{const d=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8"));const s=new Set();for(const c of d.connections||[]){if(c.tls&&c.tls.client_keystore_password_env)s.add(c.tls.client_keystore_password_env)}console.log([...s].join(" "))}catch(e){}' "$CONN" 2>/dev/null)"
fi
for n in $PWENV; do check_var "$n" req "пароль PKCS12; введите перед запуском: read -rs $n; export $n"; done
if [ "$NOAI" = 0 ]; then
  case "$AIMODE" in
    local)
      ok "LT_VERDICT_AI_RUNNER_MODE=local (direct, ADR 0027: без Docker и relay)"
      check_var LT_VERDICT_AI_LOCAL_QWEN_CMD req "имя команды GigaCode (gigacode, qwen) или абсолютный путь к файлу"
      check_var LT_VERDICT_AI_LOCAL_QWEN_SHA256 opt "необязательно: sha256 файла CLI; без него продукт запишет фактический хэш в провенанс"
      check_var LT_VERDICT_AI_LOCAL_QWEN_PREFIX_ARGS opt "токены перед флагами CLI, например qwen (для 'gigacode qwen ...') или --no-install gigacode (для npx)"
      check_var LT_VERDICT_AI_LOCAL_PASSTHROUGH_ENV opt "имена переменных окружения, нужных самому CLI"
      check_var LT_VERDICT_AI_MODELS_FILE req "ОБЯЗАТЕЛЕН в режиме local: слаг модели CLI (без него MODEL_CONFIG_INVALID); шаблон config/ai-models.fork.example.json"
      if setp LT_VERDICT_AI_LOCAL_AUTH_TYPE; then ok "LT_VERDICT_AI_LOCAL_AUTH_TYPE задана"; else warn "LT_VERDICT_AI_LOCAL_AUTH_TYPE не задана" "Qwen Code с --bare без --auth-type не стартует; укажите способ входа CLI (например qwen-oauth)"; fi
      setp LT_VERDICT_AI_LOCAL_OMIT_BARE && info "LT_VERDICT_AI_LOCAL_OMIT_BARE=${LT_VERDICT_AI_LOCAL_OMIT_BARE}: --bare не передаётся"
      setp LT_VERDICT_AI_LOCAL_EXTRA_ARGS && info "LT_VERDICT_AI_LOCAL_EXTRA_ARGS задана: аргументы добавляются в конец команды CLI"
      ;;
    bad) fail "LT_VERDICT_AI_RUNNER_MODE задана неверно" "допустимо только значение local (регистр важен) или не задавать; иначе ИИ UNAVAILABLE/RUNNER_ARTIFACT_MISSING";;
    *)
      info "LT_VERDICT_AI_RUNNER_MODE не задана: ИИ пойдёт старым путём Docker (relay + Qwen 0.21.1). Для GigaCode без Docker: export LT_VERDICT_AI_RUNNER_MODE=local"
      check_var LT_VERDICT_AI_MODELS_FILE opt "без него действует встроенный ModelStudio (внешний endpoint!)"
      check_var LT_VERDICT_AI_CREDENTIAL_ENV_FILE req "без него ИИ-разбор недоступен (CREDENTIAL_NOT_CONFIGURED)"
      check_var LT_VERDICT_AI_QWEN_ROOT opt "по умолчанию ищется ltv/build/ai-runner/qwen-code-0.21.1/..."
      check_var LTV_QWEN_CMD opt "команда форка для зонда контракта (переменная только для preflight)";;
  esac
fi

# ---------------------------------------------------------------- профили источника
section "Профили источника (mTLS)"
if [ ! -f "$CONN" ]; then
  fail "нет файла профилей: $CONN" "python3 tools/make_profiles.py --config config/profile-config.json --out config/source-connections.json (см. README-ru.md)"
elif [ "$HAVE_NODE" = 1 ]; then
  sz=$(wc -c <"$CONN"); [ "$sz" -le 1048576 ] && ok "размер файла профилей $sz байт (<= 1 МиБ)" || fail "файл профилей больше 1 МиБ" "разбейте на части"
  res="$(nodejs '
const fs=require("fs");let d;
try{d=JSON.parse(fs.readFileSync(process.argv[1],"utf8"))}catch(e){console.log("BADJSON");process.exit(0)}
const out=[];const raw=fs.readFileSync(process.argv[1],"utf8");
if(/CHANGE-?ME/i.test(raw))out.push("PLACEHOLDER");
out.push("SCHEMA "+d.schema_version);
const cs=d.connections||[];out.push("N "+cs.length);
for(const c of cs){
  out.push("PROFILE "+c.id+" "+c.transport+" "+c.base_url);
  if(c.base_url&&c.base_url.startsWith("http://")&&c.tls)out.push("TLS_ON_HTTP "+c.id);
  if(c.tls){for(const k of ["ca_file","client_keystore_file"]){const p=c.tls[k];if(p){const abs=p.startsWith("/")||/^[A-Za-z]:[\\\/]/.test(p);let st="MISSING";try{fs.accessSync(p,fs.constants.R_OK);st="READABLE"}catch(e){} out.push("TLSFILE "+c.id+" "+k+" "+(abs?"abs":"RELATIVE")+" "+st+" "+p)}}}
}
console.log(out.join("\n"))' "$CONN" 2>&1)"
  if [ "$res" = BADJSON ]; then fail "файл профилей не JSON: $CONN" "проверьте синтаксис"; else
    printf '%s\n' "$res" | grep -q '^PLACEHOLDER' && fail "в файле профилей остались CHANGE-ME" "заполните profile-config.json и пересоберите профили"
    printf '%s\n' "$res" | grep -q '^SCHEMA source-connections.v[123]$' && ok "$(printf '%s\n' "$res" | grep '^SCHEMA' ) , профилей: $(printf '%s\n' "$res" | sed -n 's/^N //p')" || fail "неожиданная schema_version" "ожидается source-connections.v1..v3"
    printf '%s\n' "$res" | grep '^PROFILE ' | while read -r _ id tr url; do info "профиль $id: $tr $url"; done
    for id in $(printf '%s\n' "$res" | sed -n 's/^TLS_ON_HTTP //p'); do fail "профиль $id: tls при http://" "mTLS допустим только при https:// (SOURCE_CONFIG_INVALID)"; done
    # while в подоболочке не меняет счётчики; перечитываем построчно через временный файл
    printf '%s\n' "$res" | grep '^TLSFILE' >"$TMPD/tlsfiles"
    if [ -s "$TMPD/tlsfiles" ]; then
      while read -r _ id key abs st path; do
        if [ "$abs" = RELATIVE ]; then echo "FAIL|$id $key: путь не абсолютный ($path)|продукт принимает только абсолютные пути (SOURCE_CONFIG_INVALID); пересоберите профили с абсолютными путями"
        elif [ "$st" != READABLE ]; then echo "FAIL|$id $key: файл не найден или не читается ($path)|положите файл в tls/ и проверьте права (chmod 600, владелец - пользователь запуска)"
        else echo "OK|$id $key: файл читается ($path)|"; fi
      done <"$TMPD/tlsfiles" | sort -u >"$TMPD/tlsres"
      while IFS='|' read -r st msg hint; do if [ "$st" = OK ]; then ok "$msg"; else fail "$msg" "$hint"; fi; done <"$TMPD/tlsres"
    else info "в профилях нет блока tls (допустимо для http-стенда или публичного CA)"; fi
  fi
else skip "разбор профилей: нужен node"; fi

fi
# ---------------------------------------------------------------- сеть: TCP/TLS
parse_url() { # url -> "scheme host port path"
  local u="$1" scheme rest hostport host port
  scheme="${u%%://*}"; rest="${u#*://}"; hostport="${rest%%/*}"
  case "$hostport" in \[*\]*) host="${hostport%%]*}"; host="${host#[}"; port="${hostport##*]}"; port="${port#:}";; *) host="${hostport%%:*}"; port=""; case "$hostport" in *:*) port="${hostport##*:}";; esac;; esac
  [ -z "$port" ] && { [ "$scheme" = https ] && port=443 || port=80; }
  echo "$scheme $host $port"
}
tcp_check() { # host port
  if [ -n "$TO" ]; then $TO 6 bash -c "exec 3<>/dev/tcp/$1/$2" 2>/dev/null; else bash -c "exec 3<>/dev/tcp/$1/$2" 2>/dev/null; fi
}
tls_check() { # label url ca cert key
  local label="$1" url="$2" ca="$3" cert="$4" key="$5" scheme host port args out
  read -r scheme host port < <(parse_url "$url")
  if ! tcp_check "$host" "$port"; then fail "$label: TCP $host:$port недоступен" "сеть/VPN/прокси/фаервол, имя узла (DNS), порт; проверьте URL"; return; fi
  ok "$label: TCP $host:$port соединяется"
  [ "$scheme" = https ] || { info "$label: схема $scheme, TLS не проверяется"; return; }
  have openssl || { skip "$label: openssl нет, TLS не проверен"; return; }
  args=(-connect "$host:$port" -verify_return_error -brief)
  case "$host" in *[!0-9.:]*) args+=(-servername "$host" -verify_hostname "$host");; *) args+=(-verify_ip "$host");; esac
  [ -n "$ca" ] && [ -r "$ca" ] && args+=(-CAfile "$ca")
  [ -n "$cert" ] && [ -r "$cert" ] && args+=(-cert "$cert")
  [ -n "$key" ] && [ -r "$key" ] && args+=(-key "$key")
  out="$(printf '' | ${TO:+$TO 10} openssl s_client "${args[@]}" 2>&1)"
  if printf '%s' "$out" | grep -q 'Verification: OK\|Verification: Verified'; then
    ok "$label: TLS-рукопожатие, цепочка и имя узла проверены ($(printf '%s' "$out" | sed -n 's/^Protocol version: *//p;s/^Protocol *: *//p' | head -1))"
  else
    fail "$label: TLS не проверен: $(printf '%s' "$out" | grep -i -m1 'verif\|error\|alert\|unable' | cut -c1-140)" "CA сервера нет в ca.pem; имя узла не входит в SAN (для IP нужен SAN типа IP); сервер требует клиентский сертификат (укажите LTV_TLS_CLIENT_CERT_PEM/KEY или --deep); несовместимый протокол"
  fi
}
# Для mTLS на TLS 1.3 сервер отвергает отсутствие клиентского сертификата ПОСЛЕ рукопожатия: s_client без -cert
# может показать Verification OK, а запрос всё равно получит отказ. Поэтому полная проверка - --deep (curl с сертификатом).

CA_FILE="${LTV_TLS_CA_FILE:-}"; P12="${LTV_TLS_CLIENT_P12:-}"; CERT="${LTV_TLS_CLIENT_CERT_PEM:-}"; KEY="${LTV_TLS_CLIENT_KEY_PEM:-}"
if [ "$NONET" = 0 ]; then
  section "Сеть: источники метрик"
  if setp GRAFANA_URL; then tls_check "Grafana ($GRAFANA_URL)" "$GRAFANA_URL" "$CA_FILE" "$CERT" "$KEY"; else skip "Grafana: GRAFANA_URL не задан"; fi
  [ -z "$CERT" ] && [ "$DEEP" = 0 ] && [ -n "$PWENV" ] && info "быстрая проверка TLS идёт БЕЗ клиентского сертификата: при TLS 1.3 сервер с обязательным mTLS отвергает его отсутствие после рукопожатия; итог даёт --deep"
  if setp PROMETHEUS_URL; then tls_check "Prometheus ($PROMETHEUS_URL)" "$PROMETHEUS_URL" "$CA_FILE" "$CERT" "$KEY"; fi

  if [ "$DEEP" = 1 ]; then
    section "Глубокая проверка mTLS (--deep)"
    # PKCS12: пароль и срок (openssl читает файл на ЭТОЙ машине; значения не печатаются)
    if [ -n "$P12" ] && [ -r "$P12" ] && have openssl && setp "${PWENV%% *}"; then
      pwv="${PWENV%% *}"
      if openssl pkcs12 -in "$P12" -passin "env:$pwv" -nokeys -clcerts -out "$TMPD/client-cert.pem" >/dev/null 2>&1; then
        ok "PKCS12 открывается с паролем из \$$pwv"
        enddate="$(openssl x509 -in "$TMPD/client-cert.pem" -noout -enddate 2>/dev/null | sed 's/notAfter=//')"
        if openssl x509 -in "$TMPD/client-cert.pem" -noout -checkend 0 >/dev/null 2>&1; then
          if openssl x509 -in "$TMPD/client-cert.pem" -noout -checkend $((7*86400)) >/dev/null 2>&1; then ok "клиентский сертификат действует до: $enddate"; else warn "клиентский сертификат истекает в течение 7 дней: $enddate" "продукт отказывает SOURCE_TLS_CLIENT_CERT_EXPIRED после истечения"; fi
        else fail "клиентский сертификат истёк: $enddate" "выпустите новый"; fi
        # извлекаем ключ во временный файл 0600 только чтобы передать curl/openssl; удаляется при выходе
        ( umask 077; openssl pkcs12 -in "$P12" -passin "env:$pwv" -nocerts -nodes -out "$TMPD/client-key.pem" >/dev/null 2>&1 )
        [ -z "$CERT" ] && CERT="$TMPD/client-cert.pem"; [ -z "$KEY" ] && KEY="$TMPD/client-key.pem"
      else fail "PKCS12 не открывается" "неверный пароль в \$$pwv, файл не PKCS12 (JKS/PEM не поддерживаются) или повреждён"; fi
    else skip "PKCS12: нужны LTV_TLS_CLIENT_P12, openssl и пароль в переменной"; fi
    if have curl && setp GRAFANA_URL; then
      cargs=(-sS -o "$TMPD/curl.body" -w '%{http_code}' --max-time 15)
      [ -n "$CA_FILE" ] && [ -r "$CA_FILE" ] && cargs+=(--cacert "$CA_FILE")
      [ -n "$CERT" ] && [ -r "$CERT" ] && [ -n "$KEY" ] && [ -r "$KEY" ] && cargs+=(--cert "$CERT" --key "$KEY")
      code="$(curl "${cargs[@]}" "${GRAFANA_URL%/}/api/health" 2>"$TMPD/curl.err")"; rc=$?
      if [ $rc -eq 0 ] && [ "$code" = 200 ]; then ok "mTLS: GET /api/health -> 200 (только чтение, без авторизации)"
      elif [ $rc -eq 0 ]; then warn "GET /api/health -> HTTP $code" "400 'No required SSL certificate' = нет/чужой клиентский сертификат; 401/403 = TLS прошёл, нужен токен (профиль auth bearer, LTV_METRICS_TOKEN); 404 = другой путь health за прокси"
      else fail "curl: код $rc: $(head -c 160 "$TMPD/curl.err")" "60 = сервер не доверен (ca.pem); 55/56/58/35 = сертификат/ключ отвергнуты (55/56 - сервер отверг клиентский сертификат после рукопожатия TLS 1.3, код зависит от версии curl); 51/ssl = имя не в SAN; 28 = таймаут"; fi
    else skip "mTLS-запрос: нужны curl и GRAFANA_URL"; fi
  fi
else section "Сеть"; skip "--no-net: сетевые проверки пропущены"; fi

# ---------------------------------------------------------------- ИИ
if [ "$NOAI" = 0 ]; then
  section "ИИ: файл моделей, форк Qwen/GigaCode"
  DIRECT_CMD=""
  if [ "$AIMODE" = local ]; then
    LRUN="$HERE/ltv/tools/advisory_ai_runtime_local.sh"
    if [ -f "$LRUN" ]; then ok "в сборке есть tools/advisory_ai_runtime_local.sh (ADR 0027)"; else fail "в сборке нет tools/advisory_ai_runtime_local.sh" "сборка без режима direct: пересоберите из main после слияния ADR 0027 (rebuild-bundle.ps1)"; fi
    LB="${LT_VERDICT_AI_LOCAL_BASH:-bash}"; if have "$LB"; then ok "bash для launcher: $LB"; else fail "bash не найден ($LB)" "LT_VERDICT_AI_LOCAL_BASH"; fi
    DC="${LT_VERDICT_AI_LOCAL_QWEN_CMD:-}"
    if [ -z "$DC" ]; then info "команда CLI не задана: имя (gigacode, qwen) или абсолютный путь; готовые строки печатает ./print-ai-env.sh <имя-или-путь> (например ./print-ai-env.sh gigacode)"; fi
    PREFIX=""
    if [ -n "${LT_VERDICT_AI_LOCAL_QWEN_PREFIX_ARGS:-}" ]; then
      PN=0; PBAD=0
      for t in $LT_VERDICT_AI_LOCAL_QWEN_PREFIX_ARGS; do PN=$((PN+1)); printf '%s' "$t" | grep -Eq '^[A-Za-z0-9._:/=@,+-]{1,200}$' || PBAD=1; done
      if [ "$PN" -le 16 ] && [ "$PBAD" = 0 ]; then ok "LT_VERDICT_AI_LOCAL_QWEN_PREFIX_ARGS: $PN токен(а) ставятся перед флагами CLI ($LT_VERDICT_AI_LOCAL_QWEN_PREFIX_ARGS)"; PREFIX="$LT_VERDICT_AI_LOCAL_QWEN_PREFIX_ARGS"
      else fail "LT_VERDICT_AI_LOCAL_QWEN_PREFIX_ARGS некорректна" "до 16 токенов через пробел, символы A-Za-z0-9._:/=@,+- без кавычек"; fi
    fi
    if [ -n "$DC" ]; then
      NAME="$DC"
      case "$DC" in
        /*|[A-Za-z]:/*) ;;
        *) if printf '%s' "$DC" | grep -Eq '^[A-Za-z0-9][A-Za-z0-9._+-]{0,63}$'; then
             DC="$(command -v -- "$NAME" 2>/dev/null || true)"
             if [ -n "$DC" ] && [ -f "$DC" ]; then
               ok "имя команды '$NAME' найдено на PATH этого терминала: $DC"
               if [ -L "$DC" ]; then info "'$DC' - символическая ссылка на $(readlink -f "$DC" 2>/dev/null); продукт запускает и хэширует файл по найденному пути"; fi
               info "продукт ищет команду на PATH процесса, который запускает ltv: запускайте start.sh из того же окружения (тот же пользователь, тот же PATH)"
             else fail "команда '$NAME' не найдена на PATH" "RUNNER_ARTIFACT_MISSING в продукте; проверьте установку CLI и PATH этого терминала (command -v $NAME) или укажите абсолютный путь"; DC=""; fi
           else fail "LT_VERDICT_AI_LOCAL_QWEN_CMD недопустимо: $DC" "допустимы имя команды (A-Za-z0-9._+-, без /) или абсолютный путь"; DC=""; fi;;
      esac
      if [ -z "$DC" ]; then :
      elif [ ! -f "$DC" ]; then fail "файл CLI не найден: $DC" "RUNNER_ARTIFACT_MISSING в продукте"
      else
        case "$DC" in
          *.js|*.mjs|*.cjs) LN="${LT_VERDICT_AI_LOCAL_NODE:-node}"; if have "$LN"; then ok "entry .js запускается через $LN"; DIRECT_CMD="$LN $DC${PREFIX:+ $PREFIX}"; else fail "node не найден ($LN)" "LT_VERDICT_AI_LOCAL_NODE"; fi;;
          *) if [ -x "$DC" ]; then ok "CLI исполняемый файл: $DC"; DIRECT_CMD="$DC${PREFIX:+ $PREFIX}"; else fail "CLI не исполняемый: $DC" "chmod +x"; fi;;
        esac
        PIN="${LT_VERDICT_AI_LOCAL_QWEN_SHA256:-}"
        if have sha256sum; then
          ACT="$(sha256sum "$DC" | cut -d' ' -f1)"
          if [ -z "$PIN" ]; then info "SHA-256 не закреплён (необязательно): продукт не сверяет файл, а запишет в провенанс фактический хэш $ACT (хэшируется первый файл команды, не пакет за ним)"
          elif ! printf '%s' "$PIN" | grep -Eqi '^[0-9a-f]{64}$'; then fail "LT_VERDICT_AI_LOCAL_QWEN_SHA256 задан, но не 64 hex" "уберите переменную или поставьте фактический sha256 этого файла: $ACT (иначе продукт не запустит ИИ)"
          elif [ "$(printf '%s' "$PIN" | tr 'A-F' 'a-f')" = "$ACT" ]; then ok "sha256 CLI совпадает с закреплённым ($ACT)"
          else fail "sha256 CLI НЕ совпадает с закреплённым" "фактический: $ACT; в продукте будет RUNNER_ARTIFACT_MISMATCH. Если файл обновляли осознанно - обновите LT_VERDICT_AI_LOCAL_QWEN_SHA256 или уберите переменную"; fi
        else skip "sha256sum нет: хэш CLI не проверен"; fi
      fi
    fi
    if [ -n "${LT_VERDICT_AI_LOCAL_PASSTHROUGH_ENV:-}" ]; then
      for n in $(printf '%s' "$LT_VERDICT_AI_LOCAL_PASSTHROUGH_ENV" | tr ',' ' '); do
        if printf '%s' "$n" | grep -Eq '^[A-Za-z_][A-Za-z0-9_]*$'; then
          if setp "$n"; then ok "пробрасываемая переменная $n задана (значение не печатается)"; else warn "пробрасываемая переменная $n НЕ задана" "CLI её не получит; задайте в окружении процесса, который запускает start.sh"; fi
        else fail "некорректное имя в PASSTHROUGH_ENV: $n" "только имена [A-Za-z_][A-Za-z0-9_]*"; fi
      done
    fi
    info "вход в GigaCode через браузер делает человек вручную ДО демо; preflight его не проверяет и запросов к модели не шлёт. Если CLI хранит вход только в settings.json, --bare его не прочитает (ADR 0027, открытый вопрос)"
  fi
  MODELS="${LT_VERDICT_AI_MODELS_FILE:-}"
  LLM_EP="${LLM_URL:-}"
  if [ -n "$MODELS" ]; then
    if [ ! -f "$MODELS" ]; then fail "файл моделей не найден: $MODELS" "продукт пишет MODEL_CONFIG_INVALID и ИИ-разбор будет недоступен; путь абсолютный (ADR 0023)"
    elif [ "$HAVE_NODE" = 1 ]; then
      mres="$(nodejs '
const fs=require("fs");const p=process.argv[1];const b=fs.readFileSync(p);const o=[];
if(b.length>65536)o.push("ERR размер больше 65536 байт");
let d;try{d=JSON.parse(b.toString("utf8"))}catch(e){console.log("ERR не JSON");process.exit(0)}
if(d.schema_version!=="ai-models.v1")o.push("ERR schema_version не ai-models.v1");
const ids=(d.models||[]).map(m=>m.id);
if(!ids.length||ids.length>32)o.push("ERR models: нужно 1..32 элемента");
if(!ids.includes(d.default_model))o.push("ERR default_model не из models");
const slug=/^[A-Za-z0-9][A-Za-z0-9._:\/-]{0,127}$/;for(const i of ids){if(!slug.test(i)||i.includes("..")||i.includes("//"))o.push("ERR недопустимый id модели: "+i)}
const known=new Set(["schema_version","endpoint","default_model","models"]);for(const k of Object.keys(d))if(!known.has(k))o.push("ERR неизвестное поле верхнего уровня: "+k);
if(d.endpoint){const u=d.endpoint.url||"";if(!/^https?:\/\/[^\/?#@ ]+/.test(u))o.push("ERR endpoint.url");if(u.startsWith("http://")&&!d.endpoint.allow_insecure_http)o.push("ERR http без allow_insecure_http");if(/CHANGE-?ME/i.test(u)||/CHANGE-?ME/i.test(JSON.stringify(d)))o.push("ERR остались CHANGE-ME");o.push("URL "+u)}else o.push("NOEP");
o.push("DEFAULT "+d.default_model);console.log(o.join("\n"))' "$MODELS" 2>&1)"
      if printf '%s\n' "$mres" | grep -q '^ERR'; then printf '%s\n' "$mres" | grep '^ERR' | while read -r _ rest; do echo "$rest"; done >"$TMPD/merr"; fail "файл моделей не проходит проверку: $(tr '\n' ';' <"$TMPD/merr")" "поправьте по docs/advisory-ai.md (ai-models.v1); итоговая строгая проверка - в продукте при старте (stderr MODEL_CONFIG_INVALID)"
      else ok "файл моделей: ai-models.v1, модель по умолчанию $(printf '%s\n' "$mres" | sed -n 's/^DEFAULT //p')"; fi
      u="$(printf '%s\n' "$mres" | sed -n 's/^URL //p')"; [ -n "$u" ] && [ -z "$LLM_EP" ] && LLM_EP="$u"
      [ "$AIMODE" != local ] && printf '%s\n' "$mres" | grep -q '^NOEP' && warn "в файле моделей нет endpoint" "тогда действует встроенный ModelStudio (внешний интернет-endpoint) - для он-прем контура это не то, что нужно"
    else skip "файл моделей: нужен node для разбора"; fi
  elif [ "$AIMODE" = local ]; then fail "файл моделей не задан" "в режиме local он обязателен (слаг идёт как --model=<слаг>); без него MODEL_CONFIG_INVALID: скопируйте config/ai-models.fork.example.json в config/ai-models.json и задайте LT_VERDICT_AI_MODELS_FILE"
  else info "LT_VERDICT_AI_MODELS_FILE не задан: ИИ пойдёт на встроенный внешний endpoint ModelStudio - для он-прем контура задайте файл"; fi

  CRED="${LT_VERDICT_AI_CREDENTIAL_ENV_FILE:-}"
  if [ "$AIMODE" = local ]; then CRED=""; fi
  if [ -n "$CRED" ]; then
    if [ -f "$CRED" ]; then
      csz=$(wc -c <"$CRED"); lines=$(grep -c '' "$CRED"); good=$(grep -c '^OPENAI_API_KEY=.' "$CRED")
      if [ "$csz" -ge 1 ] && [ "$csz" -le 8192 ] && [ "$lines" -eq 1 ] && [ "$good" -eq 1 ]; then ok "credential-файл: одна строка OPENAI_API_KEY=..., $csz байт (значение не читалось и не печатается)"
      else fail "credential-файл не в формате продукта" "нужна ровно одна строка OPENAI_API_KEY=<ключ>, до 8192 байт"; fi
      perm="$(stat -c '%a' "$CRED" 2>/dev/null || true)"; [ -n "$perm" ] && [ "${perm: -2}" != 00 ] && warn "credential-файл доступен другим пользователям (права $perm)" "chmod 600"
    else fail "credential-файл не найден: $CRED" "создайте файл вне бандла и каталога данных"; fi
  fi

  if [ "$NONET" = 0 ] && [ "$AIMODE" != local ]; then
    if [ -n "$LLM_EP" ]; then tls_check "LLM endpoint ($LLM_EP)" "$LLM_EP" "${LTV_LLM_CA_FILE:-}" "" ""
      info "ВАЖНО: relay продукта (контейнер Node) использует доверие Node по умолчанию; приватный CA LLM-endpoint в нём не настроить без доработки раннера"
    else skip "LLM endpoint: не задан (LLM_URL или endpoint.url в файле моделей)"; fi
  fi

  # --- форк Qwen
  QCMD="${LTV_QWEN_CMD:-}"
  [ "$AIMODE" = local ] && QCMD="$DIRECT_CMD"
  if [ -z "$QCMD" ]; then skip "форк Qwen: команда не задана (LT_VERDICT_AI_LOCAL_QWEN_CMD или LTV_QWEN_CMD) или не прошла проверки выше"
  else
    # shellcheck disable=SC2086
    set -- $QCMD
    if ! have "$1" && [ ! -x "$1" ]; then fail "команда форка не найдена: $1" "укажите путь в LTV_QWEN_CMD (например /opt/qwen-fork/bin/qwen или 'node /opt/qwen-fork/cli-entry.js')"
    else
      QENV=(env -i PATH="$PATH" HOME="$TMPD" QWEN_HOME="$TMPD" QWEN_RUNTIME_DIR="$TMPD" TEMP="$TMPD" TMP="$TMPD" OPENAI_API_KEY=preflight-dummy QWEN_TELEMETRY_ENABLED=0 QWEN_USAGE_STATISTICS_ENABLED=0 NO_BROWSER=1)
      PCWD=""; [ "$AIMODE" = local ] && [ -n "${LT_VERDICT_AI_LOCAL_CWD:-}" ] && [ -d "$LT_VERDICT_AI_LOCAL_CWD" ] && PCWD="$LT_VERDICT_AI_LOCAL_CWD"
      ver="$(cd "${PCWD:-.}" && "${QENV[@]}" ${TO:+$TO 30} $QCMD --version 2>&1 | head -3 | tr '\n' ' ')"
      if [ -n "$ver" ]; then
        info "форк: --version -> ${ver}"
        if [ "$AIMODE" = local ]; then info "версия форка не закрепляется продуктом (проверяется только форма строки в init)"; else case "$ver" in *0.21.1*) info "версия 0.21.1 совпадает с закреплённой апстрим-версией продукта (SHA entrypoint см. ниже)";; *) warn "версия форка отличается от закреплённой 0.21.1" "Docker-раннер сверяет версию 0.21.1 и SHA-256 cli-entry.js (RUNNER_ARTIFACT_MISMATCH); для форка используйте режим local";; esac; fi
      else fail "форк не отвечает на --version" "проверьте команду и Node"; fi
      QROOT="${LT_VERDICT_AI_QWEN_ROOT:-}"
      if [ -n "$QROOT" ] && [ -f "$QROOT/cli-entry.js" ]; then
        if have sha256sum; then sh="$(sha256sum "$QROOT/cli-entry.js" | cut -d' ' -f1)"; ref=1db9709bf1753611ca2fec234cf5adf517376efeb1540fcf9e309da010f9ed38
          [ "$sh" = "$ref" ] && ok "cli-entry.js SHA-256 = эталон 0.21.1" || info "cli-entry.js SHA-256 = $sh (не эталон 0.21.1; для форка это ожидаемо - занесите в раннер как новый закреплённый хэш)"; fi
      fi
      # --help: в 0.21.1 многие флаги скрыты, поэтому по справке судим только справочно
      helptxt="$(cd "${PCWD:-.}" && "${QENV[@]}" ${TO:+$TO 30} $QCMD --help 2>&1)"
      miss=""; for f in --output-format --safe-mode --model; do printf '%s' "$helptxt" | grep -q -- "$f" || miss="$miss $f"; done
      [ -z "$miss" ] && info "--help содержит базовые флаги (--output-format, --safe-mode, --model); скрытые флаги проверяет зонд ниже" || warn "в --help не найдены:$miss" "возможно, справка форка устроена иначе; решает зонд ниже"
      # --- зонд контракта: ровно argv продукта, но на закрытый loopback-порт и фиктивный ключ. Ничего наружу не уходит.
      if [ "$HAVE_NODE" = 1 ]; then
        W="$TMPD/probe"; mkdir -p "$W"; echo '{"probe":true}' >"$W/evidence.json"
        SCHEMA="$HERE/ltv/docs/contracts/advice/v1/ai-advice-output.schema.json"; [ -f "$SCHEMA" ] || SCHEMA="$HERE/ltv/docs/contracts/advice/v1/ai-advice-output.schema.json"
        if [ ! -f "$SCHEMA" ]; then fail "нет схемы ltv/docs/contracts/advice/v1/ai-advice-output.schema.json" "бандл собран не полностью"; else
          BARE_ARG=(--bare); [ "${LT_VERDICT_AI_LOCAL_OMIT_BARE:-0}" = 1 ] && BARE_ARG=()
          XARGS=(); [ "$AIMODE" = local ] && [ -n "${LT_VERDICT_AI_LOCAL_EXTRA_ARGS:-}" ] && read -r -a XARGS <<<"$LT_VERDICT_AI_LOCAL_EXTRA_ARGS"
          ( cd "${PCWD:-$W}" && "${QENV[@]}" ${TO:+$TO 90} $QCMD ${BARE_ARG[@]+"${BARE_ARG[@]}"} --safe-mode --auth-type=openai --model=preflight-probe-model \
              --openai-base-url=http://127.0.0.1:1/v1 --system-prompt=preflight-probe --input-format=text --output-format=json \
              --json-schema=@"$SCHEMA" --exclude-tools=read_file,edit,notebook_edit,run_shell_command --max-tool-calls=0 \
              --max-wall-time=20s --approval-mode=default --chat-recording=false --openai-logging=false --telemetry=false ${XARGS[@]+"${XARGS[@]}"} \
              <"$W/evidence.json" >"$W/out.txt" 2>"$W/err.txt" ); prc=$?
          if grep -qi 'unknown argument\|unrecognized\|unknown option' "$W/err.txt"; then
            fail "форк не принимает флаги продукта: $(grep -i -m2 'unknown\|unrecognized' "$W/err.txt" | tr '\n' ' ' | cut -c1-200)" "это и есть то, что нужно поправить в раннере (QwenCode0211.invocation / advisory_ai_runtime_qwen.sh)"
          else
            ok "форк принял все флаги argv продукта (--bare --safe-mode --auth-type --model --openai-base-url --system-prompt --input-format --output-format=json --json-schema --exclude-tools --max-tool-calls --max-wall-time --approval-mode --chat-recording --openai-logging --telemetry), код выхода $prc"
            pres="$(nodejs '
const fs=require("fs");const t=fs.readFileSync(process.argv[1],"utf8").trim();let ev=[];
try{const j=JSON.parse(t);ev=Array.isArray(j)?j:[j]}catch(e){for(const l of t.split("\n")){try{ev.push(JSON.parse(l))}catch(_){}}}
const o=[];if(!ev.length){console.log("NOEVENTS");process.exit(0)}
const init=ev.find(e=>e&&e.type==="system"&&e.subtype==="init");
if(!init)o.push("NOINIT");else{
 o.push("VER "+(init.qwen_code_version||"?"));
 o.push("TOOLS "+JSON.stringify(init.tools));
 o.push("MCP "+JSON.stringify(init.mcp_servers));
 o.push("MODEL "+init.model);
 o.push("PERM "+init.permission_mode);}
const res=ev.find(e=>e&&e.type==="result");o.push(res?"RESULT "+res.subtype:"NORESULT");
console.log(o.join("\n"))' "$W/out.txt" 2>&1)"
            if ! printf '%s\n' "$pres" | grep -q '^\(VER\|NOINIT\|NOEVENTS\|RESULT\|NORESULT\)'; then fail "не удалось разобрать вывод форка: $(printf '%s' "$pres" | head -c 160)" "ошибка чтения $W/out.txt узлом Node (путь/кодировка)"
            elif [ "$pres" = NOEVENTS ]; then fail "форк не вывел JSON-событий (stdout пуст или не JSON)" "продукт ждёт --output-format=json: массив событий с system/init и result"
            else
              printf '%s\n' "$pres" | grep -q '^NOINIT' && fail "нет события system/init в выводе" "продукт сверяет init: версия, tools, mcp_servers, model" || {
                ok "событие init есть: версия $(printf '%s\n' "$pres" | sed -n 's/^VER //p'), permission_mode $(printf '%s\n' "$pres" | sed -n 's/^PERM //p')"
                TL="$(printf '%s\n' "$pres" | sed -n 's/^TOOLS //p')"
                if [ "${LT_VERDICT_AI_LOCAL_OMIT_BARE:-0}" = 1 ] && printf '%s' "$TL" | grep -q '"structured_output"'; then ok "init.tools содержит structured_output (без --bare CLI регистрирует и встроенные инструменты; вызовы запрещены --max-tool-calls=0)"
                elif [ "$TL" = '["structured_output"]' ]; then ok "init.tools = [structured_output] (инструменты исключены, json-schema активен)"
                else fail "init.tools = $TL, ожидалось [\"structured_output\"]" "--json-schema/--exclude-tools действуют иначе: проверьте контракт форка"; fi
                [ "$(printf '%s\n' "$pres" | sed -n 's/^MCP //p')" = '[]' ] && ok "init.mcp_servers = [] (safe-mode действует)" || fail "init.mcp_servers не пуст: $(printf '%s\n' "$pres" | sed -n 's/^MCP //p')" "--safe-mode не отключает MCP в форке"
                [ "$(printf '%s\n' "$pres" | sed -n 's/^MODEL //p')" = preflight-probe-model ] && ok "init.model соответствует --model" || warn "init.model = $(printf '%s\n' "$pres" | sed -n 's/^MODEL //p'), передавали preflight-probe-model" "форк подменяет модель? раннер сверяет модель"; }
              printf '%s\n' "$pres" | grep -q '^RESULT' && ok "событие result есть ($(printf '%s\n' "$pres" | sed -n 's/^RESULT //p')); ошибка соединения с 127.0.0.1:1 здесь ожидаема" || warn "события result нет" "проверьте формат итогового события форка"
            fi
          fi
        fi
      else skip "зонд контракта форка: нужен node для разбора JSON"; fi
    fi
  fi

  if [ "$AIMODE" != local ]; then
  section "ИИ: что нужно для ПРОДУКТОВОГО раннера 0.21.1 (справочно)"
  have docker && ok "docker найден" || info "docker не найден: продуктовый раннер (tools/advisory_ai_runtime.ps1) запускает relay и Qwen в контейнерах"
  have pwsh && ok "pwsh найден" || info "pwsh не найден: на Linux продукт вызывает именно pwsh"
  info "образ Playwright MCP (digest 7b82f29c...) должен быть заранее в docker image store"
  fi
fi

section "Итог"
printf 'FAIL: %d, WARN: %d\n' "$FAILS" "$WARNS"
[ "$FAILS" -eq 0 ] && echo "Готово к запуску: ./start.sh$([ "$SYN" = 1 ] && echo " --synthetic")" || echo "Исправьте пункты [FAIL] и запустите preflight.sh снова."
exit "$FAILS"
