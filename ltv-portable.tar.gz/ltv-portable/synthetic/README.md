# synthetic/: входы демо без Docker

Детерминированные синтетические данные демо-стенда LT Verdict (сгенерированы `tools/demo-stand/generator/generate.py` из репозитория
продукта, режим `all-with-correlation`; хэши JTL совпадают со скриптом показа). Ядро продукта настоящее, данные - нет.

| Каталог | Сценарий | Файлы | Ожидаемый результат |
| --- | --- | --- | --- |
| `s1-sla-fail/` | 1. SLA FAIL | `load.jtl` (54 000 запросов, 15 мин, хэш `c9b049d3`) | шаблон p95 <= 1000: **PASS**, p95 **451 мс**, ошибки 0,2 %; порог 250: **FAIL** «нарушено 1 из 2» |
| `s2-capacity/` | 2. Тест максимума и колено | `load.jtl` (141 000, хэш `18be8865`), `resources.json`, `capacity-plan.json` (требование 90), `capacity-plan-req100.json`, `capacity-plan-req104.json` | **PASS**, граница **[95,745; 103,745) RPS**; req100 **NO_VERDICT**; req104 **FAIL**; колено (диагностика) между ступенями **96 и 104 RPS** (если в сборке есть ADR 0026) |
| `s3-saturation/` | 3. Насыщение | `load.jtl` (64 320, хэш `1e4c9315`) | **FAIL**, p95 **3 493 мс** при <= 1000; `db-busy` = 1 |
| `s5-correlation/` | 5. Корреляции (синтетика с заложенной связью) | `load.jtl` (96 000, хэш `5e322999`), `resources.json`, `correlation-plan.json` | **PASS**, p95 141 мс; ассоциация в стадии `steady`: **лаг 20 с, rho 0,83**, p 0,002, гипотез 2 |
| (корень) | ряды для лёгкого стенда | `metrics.om`, `manifest.json` | читает `tools/synthetic_stand.py` |

Политики лежат в `../config/policies/`:

| Файл | Для чего |
| --- | --- |
| `s1-template-p95-1000.json` | то же, что шаблон «Базовый API (SLA)» в «Правилах»: p95 <= 1000 мс, ошибки <= 5 % (сценарии 1, 3, 5) |
| `s1-strict-p95-250.json` | порог 250 мс вместо правки в редакторе (шаг 4 сценария 1) |
| `s1-sla-fail-cli.json` | политика демо-стенда для CLI: `overall-p95` 250, `checkout-p95` 300, `refund-p99` 500, ошибки, пропускная способность; код выхода 2 |
| `s2-capacity.json`, `s2-capacity-small-sample.json` | сценарий 2 и его вариант «малая выборка» |
| `s3-saturation-cli.json` | политика демо-стенда для сценария 3 в CLI (p95 <= 800) |
| `s5-correlation.json` | сценарий 5 (p95 <= 1000, ошибки <= 5 %) |
| `s4-soak-4h.json` | сценарий 4 (4 часа): данных нет в наборе, политика на случай генерации |

## Как загрузить каждый сценарий

### В интерфейсе (`./start.sh --synthetic`, затем адрес из консоли)

| Сценарий | «Новый анализ» |
| --- | --- |
| 1 | файл нагрузки `s1-sla-fail/load.jtl`; политика: шаблон «Базовый API (SLA)» на «Правилах»; источник `demo-grafana`, окно «Авто», шаг 10, запас 60, простой 60, режим шага «Фиксированный» |
| 2 | **без источника**: `s2-capacity/load.jtl`, `s2-capacity.json`, `s2-capacity/resources.json`, `s2-capacity/capacity-plan.json` |
| 3 | `s3-saturation/load.jtl`, шаблон без правок, источник `demo-grafana`, шаг 10, запас 60 |
| 5 | **без источника**: `s5-correlation/load.jtl`, `s5-correlation.json`, `s5-correlation/resources.json`, `s5-correlation/correlation-plan.json` |

Источник `demo-grafana` работает, пока запущен `tools/synthetic_stand.py` (его поднимает `./start.sh --synthetic`).

### В командной строке (без браузера и без стенда)

Корень набора, `JAVA_HOME` задан. Каталог данных любой. Коды выхода: 0 PASS, 2 FAIL, 3 NO_VERDICT.

```bash
ltv/bin/ltv analyze synthetic/s1-sla-fail/load.jtl --policy config/policies/s1-template-p95-1000.json --data-dir /tmp/ltv-d   # 0, PASS
ltv/bin/ltv analyze synthetic/s2-capacity/load.jtl --policy config/policies/s2-capacity.json \
    --resources synthetic/s2-capacity/resources.json --capacity synthetic/s2-capacity/capacity-plan.json --data-dir /tmp/ltv-d  # 0, граница 95.745..103.745
ltv/bin/ltv analyze synthetic/s5-correlation/load.jtl --policy config/policies/s5-correlation.json \
    --resources synthetic/s5-correlation/resources.json --correlation synthetic/s5-correlation/correlation-plan.json --data-dir /tmp/ltv-d
```

С онлайн-источником (сценарии 1 и 3; нужен запущенный `python3 tools/synthetic_stand.py --om synthetic/metrics.om`):

```bash
cat > /tmp/ltv-source.json <<'EOF'
{"schema_version":"source-request.v3","profile_ids":["demo-grafana"],"window":{"origin":"auto","step_ms":10000,"margin_ms":60000,"max_idle_gap_ms":1800000}}
EOF
ltv/bin/ltv analyze synthetic/s3-saturation/load.jtl --policy config/policies/s3-saturation-cli.json \
    --connections config/source-connections.synthetic-demo-stand.json --source /tmp/ltv-source.json --data-dir /tmp/ltv-d   # код 2, FAIL
```

## Чего без Grafana получить НЕЛЬЗЯ

- «Grafana evidence» (шаг 7 сценария 1): картинка панели («Render PNG») и переход на панель. Ссылка "Prepare link" строится локально, но открывать её некуда.
- Дашборд Grafana с панелями «Load», «Response time p95», «Busy ratio», «Queues» и ссылки сценариев в его шапке.
- Сценарий 4 (тест на 4 часа, 33 МБ): не входит в набор (генератор `--scenario soak-4h`).
- Рендер вне продукта: сохранённые PNG панелей, заготовленные на репетиции, в набор не входят.

`tools/synthetic_stand.py` - не Grafana и не Prometheus: понимает только запросы профиля `demo-grafana` (`round(avg_over_time(метрика{метки}[шаг]), 0.000001)`) и `/api/health`.
Для любых других выражений отвечает 400, для остальных путей 404.
