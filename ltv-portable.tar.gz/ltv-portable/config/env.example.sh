# Скопируйте в config/env.sh и заполните. Здесь ТОЛЬКО пути и имена; значения секретов в файл не пишите.
# start.sh и preflight.sh читают config/env.sh, если он есть (source). Права: chmod 600 config/env.sh.

# ===================== Режим А: живой стенд (OpenShift, Grafana/Prometheus за mTLS) =====================
export GRAFANA_URL="https://CHANGE-ME-grafana-host"          # без завершающего /
export PROMETHEUS_URL=""                                     # необязательно: прямой Prometheus (transport direct)
# Файлы кладёте вы в tls/ (в бандл они не входят)
export LTV_TLS_CA_FILE="$LTV_PORTABLE_HOME/tls/ca.pem"             # PEM с CA, которым подписан сервер
export LTV_TLS_CLIENT_P12="$LTV_PORTABLE_HOME/tls/client.p12"      # PKCS12 с клиентским ключом и цепочкой
export LTV_TLS_CLIENT_CERT_PEM=""                            # необязательно, только для curl/openssl-проверки в preflight
export LTV_TLS_CLIENT_KEY_PEM=""                             # то же (ключ preflight только передаёт в curl, не читает)
# Пароль PKCS12 - ПЕРЕМЕННАЯ ОКРУЖЕНИЯ, в файл не пишется; вводите в терминале перед start.sh:
#   read -rs LTV_GRAFANA_MTLS_PASSWORD; export LTV_GRAFANA_MTLS_PASSWORD
# Токен сервисной учётной записи Grafana (если профиль с auth bearer): LTV_METRICS_TOKEN

# Файл профилей источника (его делает tools/make_profiles.py, см. README-ru.md)
export LTV_CONNECTIONS_FILE="$LTV_PORTABLE_HOME/config/source-connections.json"

# ===================== ИИ: локальный режим direct (ADR 0027 + поправка 2026-10-08, в main с PR #199 и #200), без Docker и relay =====================
# Первые строки ниже ГОТОВИТ помощник:   ./print-ai-env.sh gigacode      (или путь к файлу; префикс: ./print-ai-env.sh gigacode qwen)
# QWEN_CMD - ИМЯ КОМАНДЫ (gigacode, qwen, npx: продукт ищет её на PATH процесса, который запускает ltv) ИЛИ АБСОЛЮТНЫЙ ПУТЬ к файлу.
# SHA-256 НЕОБЯЗАТЕЛЕН: задан - продукт сверяет файл (RUNNER_ARTIFACT_MISMATCH при отличии); не задан - в провенанс пишется фактический хэш.
# Раскомментируйте блок, когда будет готов GigaCode. Вход в CLI (браузер) человек делает вручную заранее, под тем же пользователем, что запускает ltv.
#export LT_VERDICT_AI_RUNNER_MODE=local                          # ровно "local" (регистр важен); иное значение = UNAVAILABLE
#export LT_VERDICT_AI_LOCAL_QWEN_CMD="gigacode"                  # имя команды из PATH или абсолютный путь к файлу CLI
#export LT_VERDICT_AI_LOCAL_QWEN_SHA256=""                       # необязательно: sha256 файла (его печатает print-ai-env.sh закомментированной строкой)
#export LT_VERDICT_AI_LOCAL_QWEN_PREFIX_ARGS=""                  # необязательно: токены ПЕРЕД флагами CLI, до 16: "qwen" (для "gigacode qwen ...") или "--no-install gigacode" (при QWEN_CMD=npx; тогда нужен и LT_VERDICT_AI_LOCAL_CWD=<каталог с node_modules/.bin/gigacode>: npx --no-install PATH не смотрит)
#export LT_VERDICT_AI_MODELS_FILE="$LTV_PORTABLE_HOME/config/ai-models.json"   # ОБЯЗАТЕЛЕН в режиме local: слаг модели CLI (шаблон config/ai-models.fork.example.json);
                                                                  # endpoint в файле игнорируется, слаг передаётся как --model=<слаг>
#export LT_VERDICT_AI_LOCAL_AUTH_TYPE="qwen-oauth"               # --auth-type CLI (способ входа); Qwen Code с --bare без него не стартует. Допустимое значение определяет CLI
#export LT_VERDICT_AI_LOCAL_OMIT_BARE=1                          # 1 = не передавать --bare (если после входа CLI "не видит" вход); остальные защитные флаги остаются
#export LT_VERDICT_AI_LOCAL_EXTRA_ARGS=""                        # доп. аргументы CLI В КОНЕЦ команды, через пробел; токены A-Za-z0-9._:/=@,+- без кавычек; префиксных подкоманд нет
#export LT_VERDICT_AI_LOCAL_PASSTHROUGH_ENV=""                   # имена переменных окружения (через запятую), которые копируются в окружение CLI; по умолчанию ни одной
#export LT_VERDICT_AI_LOCAL_CWD=""                               # рабочий каталог CLI; по умолчанию пустой временный
#export LT_VERDICT_AI_LOCAL_NODE=""                              # абсолютный путь к node, если CLI - .js и node не в PATH
#export LT_VERDICT_AI_LOCAL_BASH=""                              # путь к bash, если не в PATH (на Linux обычно не нужен)
# НЕ используются в режиме local: LT_VERDICT_AI_CREDENTIAL_ENV_FILE, LT_VERDICT_AI_QWEN_ROOT, LT_VERDICT_AI_RUNTIME_ROOT.

# ===================== Прочее =====================
export LTV_DATA_DIR="$LTV_PORTABLE_HOME/data"
export LTV_JAVA_OPTS="-Xmx1g"                                # уходит в JAVA_OPTS; пароли сюда не класть
