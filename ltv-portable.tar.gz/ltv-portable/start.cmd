@echo off
rem Windows (второстепенно): запуск без источника или с профилями. Параметры - переменные окружения из config\env.example.sh в виде set.
setlocal
set HERE=%~dp0
if "%LTV_DATA_DIR%"=="" set LTV_DATA_DIR=%HERE%data
if not exist "%LTV_DATA_DIR%" mkdir "%LTV_DATA_DIR%"
if "%LTV_CONNECTIONS_FILE%"=="" (
  call "%HERE%ltv\bin\ltv.bat" ui --data-dir "%LTV_DATA_DIR%"
) else (
  call "%HERE%ltv\bin\ltv.bat" ui --data-dir "%LTV_DATA_DIR%" --connections "%LTV_CONNECTIONS_FILE%"
)
