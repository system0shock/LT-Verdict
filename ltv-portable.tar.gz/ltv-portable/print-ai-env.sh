#!/usr/bin/env bash
# print-ai-env.sh <имя-команды-или-путь> [префиксные-аргументы...]: готовит строки для локального режима ИИ (ADR 0027).
#
# Продукт принимает в LT_VERDICT_AI_LOCAL_QWEN_CMD ИМЯ КОМАНДЫ (gigacode, qwen, npx; ищется через PATH процесса, который запускает ltv)
# либо АБСОЛЮТНЫЙ ПУТЬ к файлу. SHA-256 необязателен: если задан, продукт сверяет файл, иначе пишет фактический хэш в провенанс.
# Этот помощник находит файл, считает его SHA-256 и печатает готовые строки export. Ничего не запускает, не читает ключи, не шлёт запросов.
#
#   ./print-ai-env.sh gigacode                 # имя из PATH (в env.sh попадёт имя, хэш - закомментированной строкой)
#   ./print-ai-env.sh /opt/gigacode/gigacode   # путь
#   ./print-ai-env.sh gigacode qwen            # то же + LT_VERDICT_AI_LOCAL_QWEN_PREFIX_ARGS='qwen' (запуск "gigacode qwen ...")
#   ./print-ai-env.sh npx --no-install gigacode   # npx с префиксом
#   ./print-ai-env.sh gigacode >> config/env.sh   # дописать строки (предупреждения идут в stderr)
set -u
[ $# -ge 1 ] || { sed -n 2,13p "$0" >&2; exit 2; }
IN="$1"; shift
PREFIX_TOKENS=("$@")
if [ "${#PREFIX_TOKENS[@]}" -gt 16 ]; then echo "ОШИБКА: префиксных аргументов не больше 16." >&2; exit 1; fi
for t in "${PREFIX_TOKENS[@]+"${PREFIX_TOKENS[@]}"}"; do
  printf '%s' "$t" | grep -Eq '^[A-Za-z0-9._:/=@,+-]{1,200}$' || { echo "ОШИБКА: префиксный аргумент '$t' недопустим (допустимы A-Za-z0-9._:/=@,+- без кавычек)." >&2; exit 1; }
done
case "$IN" in */*) BYNAME=0;; *) BYNAME=1; printf '%s' "$IN" | grep -Eq '^[A-Za-z0-9][A-Za-z0-9._+-]{0,63}$' || { echo "ОШИБКА: имя команды '$IN' недопустимо (A-Za-z0-9._+-, до 64 знаков)." >&2; exit 1; };; esac
warn() { printf 'ВНИМАНИЕ: %s\n' "$1" >&2; }
note() { printf '%s\n' "$1" >&2; }

# --- найти файл
FOUND=""
case "$IN" in
  */*) [ -e "$IN" ] && FOUND="$IN" ;;
  *)
    FOUND="$(command -v "$IN" 2>/dev/null || true)"
    # все кандидаты на PATH (type -a: путь после слов "is"; псевдонимы и функции пропускаем)
    CANDS="$(type -aP "$IN" 2>/dev/null | awk '!seen[$0]++')"
    N="$(printf '%s\n' "$CANDS" | grep -c . || true)"
    if [ "${N:-0}" -gt 1 ]; then
      warn "на PATH несколько кандидатов для '$IN' (выбран первый):"
      printf '%s\n' "$CANDS" | sed 's/^/    /' >&2
      note "    Если нужен другой - передайте путь: ./print-ai-env.sh /полный/путь/к/файлу"
    fi;;
esac
[ -n "$FOUND" ] || { echo "ОШИБКА: '$IN' не найден (ни как путь, ни на PATH). Проверьте установку CLI и PATH этого терминала." >&2; exit 1; }
[ -f "$FOUND" ] || { echo "ОШИБКА: '$FOUND' не обычный файл (каталог или специальный файл)." >&2; exit 1; }

# --- абсолютный путь и цель симлинка
abspath() { local p="$1"; case "$p" in /*) printf '%s' "$p";; *) printf '%s/%s' "$(cd "$(dirname "$p")" && pwd)" "$(basename "$p")";; esac; }
ABS="$(abspath "$FOUND")"
TARGET="$ABS"
if [ -L "$ABS" ]; then
  if TARGET="$(readlink -f "$ABS" 2>/dev/null)" && [ -n "$TARGET" ]; then :; else TARGET="$ABS"; fi
  note "'$ABS' - символическая ссылка на '$TARGET'."
  note "    Продукт открывает файл по пути ссылки (хэш считается от содержимого цели). Если цель обновится (apt/npm/обновление CLI) - хэш изменится: при заданном SHA256 (пин) запуск даст RUNNER_ARTIFACT_MISMATCH, без пина в провенанс попадёт новый хэш."
  note "    Без пина обновление CLI не мешает; с пином закрепите проверенную копию или укажите путь цели вместо ссылки."
fi

# --- SHA-256
if command -v sha256sum >/dev/null 2>&1; then SHA="$(sha256sum "$ABS" | cut -d' ' -f1)"
elif command -v shasum >/dev/null 2>&1; then SHA="$(shasum -a 256 "$ABS" | cut -d' ' -f1)"
elif command -v openssl >/dev/null 2>&1; then SHA="$(openssl dgst -sha256 "$ABS" | sed 's/^.*= //')"
else echo "ОШИБКА: нет ни sha256sum, ни shasum, ни openssl." >&2; exit 1; fi
printf '%s' "$SHA" | grep -Eq '^[0-9a-f]{64}$' || { echo "ОШИБКА: не удалось посчитать SHA-256." >&2; exit 1; }

# --- что за файл
HEAD4="$(head -c 4 "$ABS" 2>/dev/null | od -An -tx1 | tr -d ' \n')"
KIND=binary
case "$ABS" in
  *.js|*.mjs|*.cjs) KIND=js;;
  *) if [ "$HEAD4" = 7f454c46 ]; then KIND=elf
     elif [ "$(head -c 2 "$ABS" 2>/dev/null)" = '#!' ]; then KIND=script
     fi;;
esac
case "$KIND" in
  js)
    warn "файл JavaScript: продукт запустит его через node ('node <файл>')."
    if command -v node >/dev/null 2>&1; then note "    node найден: $(command -v node) ($(node -v 2>/dev/null)). Если запускается ltv из другого окружения, задайте LT_VERDICT_AI_LOCAL_NODE=<абсолютный путь к node>."
    else warn "node не найден в PATH: задайте LT_VERDICT_AI_LOCAL_NODE=<абсолютный путь к node>, иначе RUNNER_ARTIFACT_MISSING."; fi;;
  script)
    SHEBANG="$(head -n 1 "$ABS" | tr -d '\r')"
    warn "файл - скрипт (${SHEBANG}): он запустится как исполняемый файл, нужен интерпретатор из первой строки в PATH пользователя, под которым работает ltv."
    [ -x "$ABS" ] || warn "файл НЕ исполняемый (chmod +x '$ABS'), иначе RUNNER_ARTIFACT_MISSING."
    note "    Хэш (пин и запись в провенанс) относится к самому скрипту, а не к тому, что он вызывает дальше: если это обёртка над другим бинарником, обновление бинарника хэш не изменит.";;
  elf) [ -x "$ABS" ] || warn "файл НЕ исполняемый (chmod +x '$ABS'), иначе RUNNER_ARTIFACT_MISSING.";;
  *) warn "тип файла не распознан (не ELF, не скрипт, не .js). Проверьте, что это сам CLI."; [ -x "$ABS" ] || warn "файл не исполняемый (chmod +x).";;
esac

# --- итог
if [ "$BYNAME" = 1 ]; then
  CMDVAL="$IN"
  note "Имя команды '$IN' продукт разрешит сам через PATH процесса, который запускает ltv (сейчас: '$ABS'). Запускайте start.sh из терминала с тем же PATH."
  note "    Хэш ниже посчитан от ПЕРВОГО файла с этим именем ('$TARGET'), а не от пакета за ним (например при 'npx ...' это сам npx)."
else
  CMDVAL="$ABS"
fi
{
  echo "# --- вставьте в config/env.sh (сгенерировано print-ai-env.sh) ---"
  echo "export LT_VERDICT_AI_RUNNER_MODE=local"
  echo "export LT_VERDICT_AI_LOCAL_QWEN_CMD='$CMDVAL'"
  if [ "${#PREFIX_TOKENS[@]}" -gt 0 ]; then echo "export LT_VERDICT_AI_LOCAL_QWEN_PREFIX_ARGS='${PREFIX_TOKENS[*]}'"; fi
  echo "#export LT_VERDICT_AI_LOCAL_QWEN_SHA256='$SHA'   # необязательно: раскомментируйте, чтобы закрепить ЭТОТ файл (после обновления CLI нужен новый хэш)"
}
if [ "$KIND" = js ] && ! command -v node >/dev/null 2>&1; then echo "export LT_VERDICT_AI_LOCAL_NODE='/ABSOLUTE/PATH/TO/node'   # node не найден в PATH"; fi
cat >&2 <<'EOF'

Что ещё нужно (см. ИНСТРУКЦИЯ-ДЕМО.md, шаг "как указать gigacode"):
  export LT_VERDICT_AI_MODELS_FILE="$LTV_PORTABLE_HOME/config/ai-models.json"   # ОБЯЗАТЕЛЕН: слаг модели CLI (config/ai-models.fork.example.json)
  export LT_VERDICT_AI_LOCAL_AUTH_TYPE=<способ входа CLI>                      # например qwen-oauth; Qwen Code с --bare без него не стартует
  export LT_VERDICT_AI_LOCAL_OMIT_BARE=1                                       # только если после входа CLI "не видит" вход из-за --bare
  export LT_VERDICT_AI_LOCAL_EXTRA_ARGS="--флаг=значение"                      # доп. аргументы В КОНЕЦ команды; токены A-Za-z0-9._:/=@,+- без кавычек

Если CLI запускается с подкомандой/пакетом в начале:
  gigacode qwen --model ...   ->  ./print-ai-env.sh gigacode qwen                  (PREFIX_ARGS='qwen')
  npx --no-install gigacode   ->  ./print-ai-env.sh npx --no-install gigacode      (CMD=npx, PREFIX_ARGS='--no-install gigacode')
npx --no-install НЕ просматривает PATH: пакет должен лежать в node_modules/.bin рабочего каталога CLI -> задайте
  export LT_VERDICT_AI_LOCAL_CWD=<каталог проекта, где выполнен npm install gigacode>
PREFIX_ARGS ставятся ПЕРЕД флагами продукта, EXTRA_ARGS - в конец. Обёртка-файл больше не нужна (но работает: укажите её имя или путь).
EOF
