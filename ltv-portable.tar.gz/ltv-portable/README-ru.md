# LT Verdict: портативный набор для демо (Linux)

Пошаговая инструкция для показа - **`ИНСТРУКЦИЯ-ДЕМО.md`**. Этот файл - устройство набора и справка.

Состав: `ltv/` - дистрибутив продукта (`installDist`, интерфейс встроен в jar, отдельная сборка `ui/` не нужна), `config/` - шаблоны и политики,
`tools/` - генераторы (`make_profiles.py`, `platform_profiles.py`, `synthetic_stand.py`), `tls/` - сюда кладёте сертификаты, `data/` - каталог данных продукта,
`synthetic/` - синтетические входы (режим без стенда), `docs/` - выдержки из документации, `BUILD-INFO.txt` - из какого коммита собрано и какие срезы влиты.
Секретов и сертификатов в наборе нет.

Требования: Linux x64 (дистрибутив - чистая Java), **Java 21+** (на 17 не запустится), `bash`, `openssl`, `curl`; `python3` 3.9+ (профили и синтетика),
`node` 22+ (только для GigaCode в виде `.js`).

## Быстрый старт

```bash
tar xzf ltv-portable.tar.gz && cd ltv-portable && chmod +x start.sh preflight.sh ltv/bin/ltv tools/*.py
./preflight.sh --synthetic && ./start.sh --synthetic            # режим Б: синтетика без Docker (сценарии: synthetic/README.md)
# режим А: живой стенд
cp config/env.example.sh config/env.sh && chmod 600 config/env.sh && $EDITOR config/env.sh
read -rs LTV_GRAFANA_MTLS_PASSWORD; export LTV_GRAFANA_MTLS_PASSWORD
cp config/profile-config.openshift-mtls.template.json config/profile-config.json && $EDITOR config/profile-config.json
python3 tools/make_profiles.py --config config/profile-config.json --out config/source-connections.json --ca "$PWD/tls/ca.pem" --p12 "$PWD/tls/client.p12"
./preflight.sh --deep && ./start.sh
```

Порт веб-интерфейса **каждый раз случайный** и слушает только `127.0.0.1` (параметра `--port` в продукте нет); адрес печатается строкой `Responding at ...` и пишется в `logs/ltv.log`.

## Что и куда

| Что | Где | Примечание |
| --- | --- | --- |
| Профили источника | `config/source-connections.json` (`--connections`) | читаются при старте, правка = перезапуск |
| mTLS | поле `tls` профиля: `ca_file`, `client_keystore_file`, `client_keystore_password_env` | пути **абсолютные**, PKCS12, пароль только в переменной окружения |
| Данные | `data/` (`--data-dir`) | |
| Файл моделей ИИ | `LT_VERDICT_AI_MODELS_FILE` -> `config/ai-models.json` (ADR 0023) | шаблон `config/ai-models.fork.example.json` |
| Политики | в интерфейсе («Правила») или файлы `config/policies/` | `ltv analyze --policy` |
| Профили OpenShift/JVM | `tools/make_profiles.py` поверх `tools/platform_profiles.py` | сигналы: `docs/platform-metric-packs.md` |
| Переменные окружения | `config/env.sh` (шаблон `config/env.example.sh`) | значения секретов в файлы не пишутся |

Метки реального OpenShift могут отличаться от контракта в `docs/platform-metric-packs.md` (раздел «Контракт меток»): на боевом стенде это не проверялось,
см. «Если метки не совпали» в `ИНСТРУКЦИЯ-ДЕМО.md`.

## Что проверяет preflight

`./preflight.sh [--deep] [--no-ai] [--no-net] [--synthetic]`. Java >= 21, встроенный интерфейс в jar, Node >= 22, `python3`/`openssl`/`curl`, запись в каталог данных, loopback-сокет,
**наличие** переменных (значения не печатаются), профили (JSON, `CHANGE-ME`, абсолютные пути `tls`, файлы читаются), TCP и TLS до `GRAFANA_URL`/`PROMETHEUS_URL`
(цепочка по `ca.pem` и имя узла), ИИ (ниже). С `--deep`: открытие PKCS12 паролем из окружения, срок сертификата, `curl --cert --key GET /api/health` (только чтение);
ключ из PKCS12 на время проверки извлекается во временный каталог `0700` и удаляется. Код возврата = число FAIL. Платных запросов нет.

Замечание про TLS 1.3: сервер с обязательным клиентским сертификатом отвергает его отсутствие **после** рукопожатия, поэтому быстрая проверка без `--deep` может показать
«TLS ок», а запрос получит отказ. Итог даёт `--deep` (HTTP 200).

## ИИ

Два пути запуска в продукте:

1. **Локальный режим direct (ADR 0027 и поправка 2026-10-08, в main с PR #199 и #200; проверьте `BUILD-INFO.txt`)**: `LT_VERDICT_AI_RUNNER_MODE=local`, процесс форка GigaCode запускается напрямую, без Docker, PowerShell и relay.
   Переменные: `LT_VERDICT_AI_LOCAL_QWEN_CMD` (**имя команды** `gigacode`/`qwen`, которое продукт ищет на `PATH` процесса `ltv`, или **абсолютный путь к файлу** бинарника, скрипта или `.js`; `./print-ai-env.sh <имя-или-путь> [префикс...]` напечатает готовые строки),
   `LT_VERDICT_AI_LOCAL_QWEN_SHA256` (**необязателен**: задан - файл сверяется с ним, не задан - фактический хэш запущенного файла пишется в провенанс), `LT_VERDICT_AI_LOCAL_QWEN_PREFIX_ARGS` (до 16 токенов перед флагами CLI: `qwen` для `gigacode qwen ...`, `--no-install gigacode` для `npx`),
   `LT_VERDICT_AI_LOCAL_PASSTHROUGH_ENV` (имена переменных, нужных самому CLI), `LT_VERDICT_AI_LOCAL_AUTH_TYPE`, `LT_VERDICT_AI_LOCAL_OMIT_BARE`, `LT_VERDICT_AI_LOCAL_EXTRA_ARGS` (только в конец команды), `LT_VERDICT_AI_LOCAL_CWD`, `LT_VERDICT_AI_LOCAL_NODE`, `LT_VERDICT_AI_LOCAL_BASH`.
   Вход в GigaCode делает человек в браузере заранее; продукт ключей не читает. Слаг модели - в файле моделей (`ai-models.v1`), **файл обязателен**; `endpoint.url` в этом режиме игнорируется. Не нужны `LT_VERDICT_AI_CREDENTIAL_ENV_FILE` и `LT_VERDICT_AI_QWEN_ROOT`.
   Потеряно относительно Docker (подробно в ADR 0027): сетевая изоляция CLI, relay, подсчёт запросов и повтор по схеме; в провенансе `endpoint_host: cli-builtin`.
   Открытый вопрос ADR 0027: `--bare` не читает `settings.json` пользователя; если вход хранится только там, нужен вход через переменные окружения.
2. Старый путь Docker: `powershell`/`pwsh` + Docker + relay + образ Playwright MCP + закреплённый Qwen Code 0.21.1 с SHA-256 `cli-entry.js` `1db9709b...10f9ed38`. Для демо не предполагается.

Что умеет preflight в режиме local: проверяет наличие `tools/advisory_ai_runtime_local.sh` в сборке, `bash`/`node`, что команда найдена на `PATH` (или путь абсолютный), исполняемость и **SHA-256 против закреплённого, если пин задан** (без пина печатает фактический хэш), переменные
для проброса (только факт наличия), файл моделей, и запускает CLI с теми же аргументами, что формирует продукт
(`--bare --safe-mode --auth-type=openai --model --system-prompt --input-format=text --output-format=json --json-schema=@... --exclude-tools=... --max-tool-calls=0 --max-wall-time --approval-mode=default
--chat-recording=false --openai-logging=false --telemetry=false`) на закрытый порт `127.0.0.1:1` с фиктивным ключом, в пустом окружении и временном HOME: в сеть ничего не уходит.
Проверяется: флаги приняты, вывод - JSON-события, есть `system/init` с `tools=["structured_output"]`, `mcp_servers=[]`, модель равна переданной, есть `result`.
Вход (авторизацию) preflight не проверяет: это ручной шаг.

Без ИИ демо полностью работает: кнопка «Получить рекомендации» вернёт «недоступно», анализ и вердикт детерминированы и от ИИ не зависят.

## Пересборка набора

На машине разработчика (Windows, Java 21, Node 24, git, python): `rebuild-bundle.ps1 -Ref origin/main` - fetch, worktree, `installDist` в слоте, наложение `bundle-src`, синтетика,
проверка хэшей JTL, дымовой тест (`ltv analyze` на сценариях 2 и 1), архив и sha256. Нужна после слияния PR с коленом ёмкости (ADR 0026) и режимом direct (ADR 0027).

## Типовые отказы

| Симптом | Причина | Что делать |
| --- | --- | --- |
| `UnsupportedClassVersionError` | Java < 21 | поставить Java 21+, `JAVA_HOME` |
| `SOURCE_TLS_CONFIG_INVALID` | нет файла, неверный пароль, переменная пуста, не PKCS12 | `preflight.sh --deep` |
| `SOURCE_TLS_HANDSHAKE_FAILED` | CA сервера нет в `ca.pem`, имя не в SAN | `openssl s_client -connect host:443 -servername host -CAfile tls/ca.pem -cert ... -key ...` |
| `SOURCE_HTTP_ERROR` (с повторами) | при TLS 1.3 сервер отверг клиентский сертификат после рукопожатия | сертификат другого CA; `--deep` |
| `SOURCE_HTTP_STATUS` 400 | прокси без клиентского сертификата | `tls.client_keystore_file` |
| `MODEL_CONFIG_INVALID` в консоли | файл моделей не прошёл проверку | `docs/advisory-ai.md`, «Файл конфигурации моделей» |
| `RUNNER_ARTIFACT_MISMATCH` (ИИ) | задан пин, и хэш CLI ему не равен | убрать `LT_VERDICT_AI_LOCAL_QWEN_SHA256` (пин необязателен) либо обновить осознанно и перезапустить |
| `RUNNER_ARTIFACT_MISSING` (ИИ) | имя команды не найдено на `PATH` процесса `ltv`, нет файла, `bash` или `node` для `.js` | `command -v gigacode` в том же терминале, откуда запускается `start.sh`; либо абсолютный путь |
| Нет адреса в консоли | порт случайный | строка `Responding at` или `logs/ltv.log` |
