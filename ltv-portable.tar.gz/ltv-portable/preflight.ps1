﻿[CmdletBinding()]
param([switch]$NoAi, [switch]$NoNet)
# LT Verdict portable (Windows, второстепенный вариант): проверка готовности без платных запросов.
# Значения секретов не печатаются. Полная версия проверок - preflight.sh (Linux). Код возврата = число FAIL.
Set-StrictMode -Version Latest
$Home_ = $PSScriptRoot
$script:Fails = 0; $script:Warns = 0
function Ok($m)   { Write-Host "[ OK ] $m" }
function Info($m) { Write-Host "[INFO] $m" }
function Skip($m) { Write-Host "[SKIP] $m" }
function Warn($m, $h) { Write-Host "[WARN] $m`n       -> $h"; $script:Warns++ }
function Fail($m, $h) { Write-Host "[FAIL] $m`n       -> $h"; $script:Fails++ }
function Section($t) { Write-Host "`n== $t ==" }
function HasVar($n) { return -not [string]::IsNullOrEmpty([Environment]::GetEnvironmentVariable($n)) }

Section "Java и дистрибутив"
$java = if ($env:JAVA_HOME -and (Test-Path "$env:JAVA_HOME\bin\java.exe")) { "$env:JAVA_HOME\bin\java.exe" } else { (Get-Command java -ErrorAction SilentlyContinue).Source }
if (-not $java) { Fail "Java не найдена" "установите Java 21+ или задайте JAVA_HOME" }
else {
    $v = (& cmd /c "`"$java`" -version 2>&1" | Select-Object -First 1)
    if ($v -match 'version "(\d+)') { $m = [int]$Matches[1]; if ($m -ge 21) { Ok "Java $m ($v)" } else { Fail "Java $m слишком старая" "нужна 21+" } }
    else { Warn "не разобрана версия Java: $v" "нужна 21+" }
}
if (Test-Path "$Home_\ltv\bin\ltv.bat") { Ok "ltv\bin\ltv.bat есть" } else { Fail "нет ltv\bin\ltv.bat" "распакуйте набор целиком" }
$node = Get-Command node -ErrorAction SilentlyContinue
if ($node) { $nv = (& node -v); if ([int]($nv.TrimStart('v').Split('.')[0]) -ge 22) { Ok "Node $nv" } else { Warn "Node $nv старее 22" "форк Qwen 0.21.x требует Node 22+" } } else { Warn "Node не найден" "нужен форку Qwen" }

Section "Каталог данных и переменные (только наличие)"
$data = if ($env:LTV_DATA_DIR) { $env:LTV_DATA_DIR } else { "$Home_\data" }
try { New-Item -ItemType Directory -Force $data | Out-Null; $t = Join-Path $data ".w"; Set-Content $t x; Remove-Item $t; Ok "каталог данных записываем: $data" } catch { Fail "каталог данных недоступен: $data" "права/путь" }
foreach ($n in 'GRAFANA_URL', 'LTV_CONNECTIONS_FILE') { if (HasVar $n) { Ok "$n задана" } else { Fail "$n не задана" "см. config\env.example.sh" } }
$pwEnv = @()
$conn = $env:LTV_CONNECTIONS_FILE
if ($conn -and (Test-Path $conn)) {
    $raw = Get-Content $conn -Raw -Encoding UTF8
    if ($raw -match 'CHANGE-?ME') { Fail "в профилях остались CHANGE-ME" "заполните profile-config и пересоберите" }
    try { $d = $raw | ConvertFrom-Json } catch { $d = $null; Fail "профили не JSON" "проверьте синтаксис" }
    if ($d) {
        foreach ($c in $d.connections) {
            Info "профиль $($c.id): $($c.transport) $($c.base_url)"
            if ($c.PSObject.Properties['tls']) {
                foreach ($k in 'ca_file', 'client_keystore_file') {
                    $p = $c.tls.$k
                    if ($p) { if ($p -notmatch '^([A-Za-z]:[\\/]|/)') { Fail "$($c.id) ${k}: путь не абсолютный" "нужны абсолютные пути" } elseif (Test-Path $p) { Ok "$($c.id) ${k}: файл есть" } else { Fail "$($c.id) ${k}: файл не найден ($p)" "положите в tls\" } }
                }
                if ($c.tls.client_keystore_password_env) { $pwEnv += $c.tls.client_keystore_password_env }
            }
        }
        foreach ($n in ($pwEnv | Select-Object -Unique)) { if (HasVar $n) { Ok "$n задана" } else { Fail "$n не задана" "пароль PKCS12 введите перед запуском" } }
    }
} elseif ($conn) { Fail "нет файла профилей: $conn" "py -3 tools\make_profiles.py ..." }

Add-Type @"
using System; using System.Net.Security; using System.Security.Cryptography.X509Certificates;
public static class LtvTls {
  public static X509Certificate2 Ca;
  public static RemoteCertificateValidationCallback Callback = Validate;
  static bool Validate(object s, X509Certificate c, X509Chain ch, SslPolicyErrors e) {
    if (e == SslPolicyErrors.None) return true;
    if (Ca == null || (e & SslPolicyErrors.RemoteCertificateNameMismatch) != 0) return false;
    ch.ChainPolicy.RevocationMode = X509RevocationMode.NoCheck;
    ch.ChainPolicy.VerificationFlags = X509VerificationFlags.AllowUnknownCertificateAuthority;
    ch.ChainPolicy.ExtraStore.Add(Ca);
    if (!ch.Build(new X509Certificate2(c))) return false;
    return ch.ChainElements[ch.ChainElements.Count - 1].Certificate.Thumbprint == Ca.Thumbprint;
  }
}
"@
function Test-Tls($label, $url, $caFile) {
    $u = [Uri]$url
    $client = New-Object Net.Sockets.TcpClient
    try { $iar = $client.BeginConnect($u.Host, $u.Port, $null, $null); if (-not $iar.AsyncWaitHandle.WaitOne(6000)) { throw "timeout" }; $client.EndConnect($iar) }
    catch { Fail "${label}: TCP $($u.Host):$($u.Port) недоступен" "сеть/VPN/DNS/фаервол"; return }
    Ok "${label}: TCP $($u.Host):$($u.Port) соединяется"
    if ($u.Scheme -ne 'https') { $client.Close(); return }
    try {
        [LtvTls]::Ca = $null; if ($caFile -and (Test-Path $caFile)) { [LtvTls]::Ca = New-Object Security.Cryptography.X509Certificates.X509Certificate2 $caFile }
        $ssl = New-Object Net.Security.SslStream($client.GetStream(), $false, [LtvTls]::Callback)
        $ssl.AuthenticateAsClient($u.Host)
        Ok "${label}: TLS-рукопожатие ($($ssl.SslProtocol)), цепочка и имя узла проверены"
        $ssl.Close()
    } catch { Fail "${label}: TLS не прошёл: $($_.Exception.Message)" "CA сервера нет в ca.pem; имя узла не в SAN; сервер требует клиентский сертификат" }
    $client.Close()
}
if (-not $NoNet) {
    Section "Сеть"
    if (HasVar 'GRAFANA_URL') { Test-Tls "Grafana" $env:GRAFANA_URL $env:LTV_TLS_CA_FILE }
    if (HasVar 'PROMETHEUS_URL') { Test-Tls "Prometheus" $env:PROMETHEUS_URL $env:LTV_TLS_CA_FILE }
    Info "Клиентский сертификат здесь не предъявляется (mTLS-запрос с сертификатом - preflight.sh --deep на Linux)."
    if (-not $NoAi -and (HasVar 'LLM_URL')) { Test-Tls "LLM endpoint" $env:LLM_URL $env:LTV_LLM_CA_FILE }
}

if (-not $NoAi) {
    Section "ИИ"
    foreach ($n in 'LT_VERDICT_AI_MODELS_FILE', 'LT_VERDICT_AI_CREDENTIAL_ENV_FILE', 'LTV_QWEN_CMD') { if (HasVar $n) { Ok "$n задана" } else { Info "$n не задана" } }
    if ($env:LT_VERDICT_AI_RUNNER_MODE -eq 'local') {
        Ok "LT_VERDICT_AI_RUNNER_MODE=local (direct, ADR 0027)"
        if (Test-Path "$Home_\ltv\tools\advisory_ai_runtime_local.sh") { Ok "в сборке есть advisory_ai_runtime_local.sh" } else { Fail "в сборке нет advisory_ai_runtime_local.sh" "пересоберите из main с ADR 0027" }
        $dc = $env:LT_VERDICT_AI_LOCAL_QWEN_CMD
        if (-not $dc -or -not (Test-Path $dc)) { Fail "LT_VERDICT_AI_LOCAL_QWEN_CMD не задан или файла нет" "абсолютный путь к CLI" }
        else {
            $act = (Get-FileHash $dc -Algorithm SHA256).Hash.ToLowerInvariant(); $pin = "$env:LT_VERDICT_AI_LOCAL_QWEN_SHA256".ToLowerInvariant()
            if ($pin -notmatch '^[0-9a-f]{64}$') { Fail "LT_VERDICT_AI_LOCAL_QWEN_SHA256 не задан" "фактический sha256: $act" }
            elseif ($pin -eq $act) { Ok "sha256 CLI совпадает с закреплённым" } else { Fail "sha256 CLI НЕ совпадает" "фактический: $act" }
            $env:LTV_QWEN_CMD = if ($dc -match '\.(js|mjs|cjs)$') { "node $dc" } else { $dc }
        }
    }
    if (HasVar 'LT_VERDICT_AI_MODELS_FILE') {
        try { $m = Get-Content $env:LT_VERDICT_AI_MODELS_FILE -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($m.schema_version -eq 'ai-models.v1' -and ($m.models.id -contains $m.default_model)) { Ok "файл моделей: ai-models.v1, default $($m.default_model)" } else { Fail "файл моделей не проходит базовую проверку" "docs\advisory-ai.md" }
        } catch { Fail "файл моделей не читается" "путь/JSON" }
    }
    if (HasVar 'LTV_QWEN_CMD' -and $node) {
        $parts = $env:LTV_QWEN_CMD.Split(' ', 2); $schema = "$Home_\ltv\docs\contracts\advice\v1\ai-advice-output.schema.json"
        $w = Join-Path ([IO.Path]::GetTempPath()) ("ltv-pf-" + [guid]::NewGuid().ToString('N')); New-Item -ItemType Directory $w | Out-Null
        try {
            '{"probe":true}' | Set-Content "$w\ev.json" -Encoding ascii
            $argv = @(); if ($parts.Count -gt 1) { $argv += $parts[1] }
            $argv += @('--bare', '--safe-mode', '--auth-type=openai', '--model=preflight-probe-model', '--openai-base-url=http://127.0.0.1:1/v1', '--system-prompt=preflight-probe', '--input-format=text', '--output-format=json', "--json-schema=@$schema", '--exclude-tools=read_file,edit,notebook_edit,run_shell_command', '--max-tool-calls=0', '--max-wall-time=20s', '--approval-mode=default', '--chat-recording=false', '--openai-logging=false', '--telemetry=false')
            $env:QWEN_HOME = $w; $env:HOME = $w; $env:OPENAI_API_KEY = 'preflight-dummy'; $env:QWEN_TELEMETRY_ENABLED = '0'; $env:NO_BROWSER = '1'
            $outp = Get-Content "$w\ev.json" | & $parts[0] @argv 2>"$w\err.txt"
            $text = ($outp -join "`n")
            if ((Get-Content "$w\err.txt" -Raw) -match '(?i)unknown argument|unrecognized') { Fail "форк не принимает флаги продукта" "см. README-ru.md, раздел ИИ" }
            else {
                try { $ev = $text | ConvertFrom-Json; $init = $ev | Where-Object { $_.type -eq 'system' -and $_.subtype -eq 'init' } | Select-Object -First 1
                    if (-not $init) { Fail "нет события system/init" "контракт форка" }
                    else { Ok "init: версия $($init.qwen_code_version), tools=$($init.tools -join ','), mcp_servers=$(@($init.mcp_servers).Count)"
                        if (($init.tools -join ',') -ne 'structured_output') { Fail "init.tools != [structured_output]" "json-schema/exclude-tools" }
                        if (@($init.mcp_servers).Count -ne 0) { Fail "init.mcp_servers не пуст" "safe-mode" } }
                } catch { Fail "вывод форка не JSON" "ожидается --output-format=json" }
            }
        } finally { Remove-Item -Recurse -Force $w -ErrorAction SilentlyContinue }
    }
}
Section "Итог"
Write-Host "FAIL: $script:Fails, WARN: $script:Warns"
exit $script:Fails
