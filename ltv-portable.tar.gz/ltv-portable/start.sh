#!/usr/bin/env bash
# Запуск LT Verdict (веб-интерфейс на 127.0.0.1, порт случайный; адрес печатается и пишется в logs/ltv.log).
#   ./start.sh                  режим А, боевой стенд: профили из config/source-connections.json
#   ./start.sh --synthetic      режим Б, синтетика: поднимает лёгкую замену стенда (tools/synthetic_stand.py, порт 13000)
#                               и запускает продукт с config/source-connections.synthetic-demo-stand.json
#   ./start.sh --synthetic --files-only   синтетика без замены стенда (только загрузка файлов, без онлайн-источника)
#   ./start.sh --no-preflight   не запускать preflight перед стартом
set -u
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export LTV_PORTABLE_HOME="$HERE"
MODE=live; PRE=1; FILES_ONLY=0
for a in "$@"; do case "$a" in --synthetic) MODE=synthetic;; --files-only) FILES_ONLY=1;; --no-preflight) PRE=0;; *) echo "неизвестный ключ: $a"; exit 2;; esac; done
[ -f "$HERE/config/env.sh" ] && . "$HERE/config/env.sh"
if [ "$PRE" = 1 ]; then
  if [ "$MODE" = synthetic ]; then "$HERE/preflight.sh" --synthetic || { echo "preflight: есть FAIL (для --synthetic достаточно Java/дистрибутива/каталога). Исправьте или запустите с --no-preflight."; exit 1; }
  else "$HERE/preflight.sh" || { echo; echo "preflight нашёл FAIL. Запуск остановлен (обойти: --no-preflight)."; exit 1; }; fi
fi
DATA="${LTV_DATA_DIR:-$HERE/data}"; mkdir -p "$DATA" "$HERE/logs"
export JAVA_OPTS="${LTV_JAVA_OPTS:--Xmx1g} ${JAVA_OPTS:-}"
args=(ui --data-dir "$DATA")
STAND_PID=""
cleanup() { [ -n "$STAND_PID" ] && kill "$STAND_PID" 2>/dev/null; }
trap cleanup EXIT INT TERM
if [ "$MODE" = live ]; then
  args+=(--connections "${LTV_CONNECTIONS_FILE:-$HERE/config/source-connections.json}")
elif [ "$FILES_ONLY" = 0 ]; then
  if command -v python3 >/dev/null 2>&1 && [ -f "$HERE/synthetic/metrics.om" ]; then
    python3 "$HERE/tools/synthetic_stand.py" --om "$HERE/synthetic/metrics.om" --port 13000 >"$HERE/logs/synthetic_stand.log" 2>&1 &
    STAND_PID=$!
    sleep 2
    if kill -0 "$STAND_PID" 2>/dev/null; then
      echo "Синтетический стенд запущен (PID $STAND_PID, порт 127.0.0.1:13000). Источник в интерфейсе: demo-grafana."
      args+=(--connections "$HERE/config/source-connections.synthetic-demo-stand.json")
    else
      STAND_PID=""; echo "ВНИМАНИЕ: синтетический стенд не стартовал (порт 13000 занят? см. logs/synthetic_stand.log). Продолжаю без онлайн-источника: загрузка файлов из synthetic/ работает."
    fi
  else
    echo "ВНИМАНИЕ: нет python3 или synthetic/metrics.om - запускаю без онлайн-источника (только файлы из synthetic/)."
  fi
fi
echo "Запуск: ltv ${args[*]}"
echo "Адрес появится ниже (Responding at http://127.0.0.1:<порт>). Остановка: Ctrl+C."
echo "Если браузер на другой машине: ssh -L <порт>:127.0.0.1:<порт> user@host (порт смотрите в строке выше)."
# stderr продукта содержит адрес и коды MODEL_CONFIG_INVALID; секреты там не печатаются
"$HERE/ltv/bin/ltv" "${args[@]}" 2>&1 | tee -a "$HERE/logs/ltv.log"
